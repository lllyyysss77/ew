import { useState, useEffect, useCallback, useRef } from 'react';
import { pageAwareness, AgentInsight, PageEvent } from '../services/pageAwareness';

export interface AgentContext {
  currentSpot: string | null;
  userInterests: string[];
  recentKeywords: string[];
  activeSection: string | null;
  interactionCount: number;
  sessionDuration: number;
  recentEvents: PageEvent[];
}

export const useAgentAwareness = () => {
  const [context, setContext] = useState<AgentContext>({
    currentSpot: null,
    userInterests: [],
    recentKeywords: [],
    activeSection: null,
    interactionCount: 0,
    sessionDuration: 0,
    recentEvents: []
  });

  const [isUserActive, setIsUserActive] = useState(true);
  const lastActivityRef = useRef(Date.now());

  useEffect(() => {
    const unsubscribe = pageAwareness.subscribe((insights: AgentInsight) => {
      const now = Date.now();
      const timeSinceLastActivity = now - insights.lastActivity;
      const isActive = timeSinceLastActivity < 30000; // 30秒内活跃

      setIsUserActive(isActive);
      lastActivityRef.current = insights.lastActivity;

      setContext({
        currentSpot: insights.currentSpot,
        userInterests: insights.userInterests,
        recentKeywords: insights.recentKeywords,
        activeSection: insights.activeSection,
        interactionCount: insights.interactionCount,
        sessionDuration: insights.sessionDuration,
        recentEvents: pageAwareness.getRecentEvents(5)
      });
    });

    return unsubscribe;
  }, []);

  const trackAgentAction = useCallback((action: string, data?: any) => {
    pageAwareness.trackCustomEvent('interaction', {
      action,
      source: 'agent',
      ...data
    });
  }, []);

  const getContextualSuggestions = useCallback((baseSuggestions: string[]): string[] => {
    const contextual: string[] = [];
    
    // 基于当前景点的建议
    if (context.currentSpot) {
      contextual.push(`详细介绍${context.currentSpot}`);
      contextual.push(`${context.currentSpot}的历史故事`);
      contextual.push(`${context.currentSpot}的最佳拍照点`);
    }

    // 基于用户兴趣的建议
    context.userInterests.slice(0, 2).forEach(interest => {
      if (interest.includes('历史')) {
        contextual.push('讲讲东里村的历史');
      } else if (interest.includes('拍照')) {
        contextual.push('推荐几个拍照打卡点');
      } else if (interest.includes('特产')) {
        contextual.push('介绍当地特色产品');
      } else if (interest.includes('美食')) {
        contextual.push('推荐一些当地美食');
      }
    });

    // 基于当前页面的建议
    if (context.activeSection) {
      if (context.activeSection.includes('celebrity')) {
        contextual.push('东里村有哪些名人？');
        contextual.push('名人堂的参观路线？');
      } else if (context.activeSection.includes('specials')) {
        contextual.push('特产在哪里购买？');
        contextual.push('有什么推荐的伴手礼？');
      }
    }

    // 合并去重并限制数量
    return [...new Set([...contextual, ...baseSuggestions])].slice(0, 8);
  }, [context]);

  const getProactiveMessage = useCallback((): string | null => {
    // 根据用户行为生成主动消息
    if (context.interactionCount > 10 && context.sessionDuration > 300000) { // 5分钟，10次交互
      return '您已经游览了一会儿，需要休息一下吗？附近有茶歇的地方。';
    }

    if (context.recentKeywords.includes('拍照') && context.interactionCount > 5) {
      return '我发现您对拍照很感兴趣，要不要我为您推荐几个最佳拍摄角度？';
    }

    if (context.userInterests.includes('历史') && context.activeSection?.includes('specials')) {
      return '看起来您对历史文化感兴趣，特产区的传统工艺品背后都有有趣的故事哦！';
    }

    if (context.interactionCount === 0 && context.sessionDuration > 60000) { // 1分钟无交互
      return '需要我为您介绍一下东里村吗？我可以当您的专属导游。';
    }

    return null;
  }, [context]);

  return {
    context,
    isUserActive,
    trackAgentAction,
    getContextualSuggestions,
    getProactiveMessage
  };
};