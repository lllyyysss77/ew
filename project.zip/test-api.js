// 测试API连接和知识库功能
import fetch from 'node-fetch';

const API_CONFIG = {
  SILICON_FLOW: {
    BASE_URL: 'https://api.siliconflow.cn/v1',
    API_KEY: process.env.SILICON_FLOW_API_KEY || '',
    MODEL: 'deepseek-ai/DeepSeek-R1-Distill-Qwen-7B'
  }
};

async function testAPI() {
  console.log('🔍 测试API连接...');
  
  try {
    if (!API_CONFIG.SILICON_FLOW.API_KEY) {
      throw new Error('Missing SILICON_FLOW_API_KEY environment variable');
    }
    const response = await fetch(`${API_CONFIG.SILICON_FLOW.BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_CONFIG.SILICON_FLOW.API_KEY}`
      },
      body: JSON.stringify({
        model: API_CONFIG.SILICON_FLOW.MODEL,
        messages: [
          { role: "system", content: "你是文化讲解员。请针对主题提供深度背景故事。返回JSON格式：{ \"title\": \"...\", \"content\": \"...\" }" },
          { role: "user", content: "永春华侨革命历史" }
        ],
        temperature: 0.7,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    console.log('✅ API连接成功！');
    console.log('📝 响应内容：', data.choices[0]?.message?.content);
    
    return data;
  } catch (error) {
    console.error('❌ API连接失败：', error.message);
    return null;
  }
}

async function testKnowledgeFunction() {
  console.log('\n🧠 测试知识库功能...');
  
  const topic = "永春东里村";
  const systemPrompt = `你是文化讲解员。请针对"${topic}"提供深度背景故事。返回JSON格式：{ "title": "...", "content": "..." }`;
  const userPrompt = topic;

  try {
    const response = await fetch(`${API_CONFIG.SILICON_FLOW.BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_CONFIG.SILICON_FLOW.API_KEY}`
      },
      body: JSON.stringify({
        model: API_CONFIG.SILICON_FLOW.MODEL,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.7,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content || "{}";
    const cleanContent = content.replace(/```json\n?|```/g, '').trim();
    const result = JSON.parse(cleanContent);
    
    console.log('✅ 知识库功能正常！');
    console.log('📚 标题：', result.title);
    console.log('📄 内容：', result.content);
    
    return result;
  } catch (error) {
    console.error('❌ 知识库功能失败：', error.message);
    return null;
  }
}

async function main() {
  console.log('🚀 开始测试Agent知识库关联功能...\n');
  
  const apiTest = await testAPI();
  if (!apiTest) {
    console.log('\n❌ API连接失败，请检查网络和API密钥');
    return;
  }
  
  const knowledgeTest = await testKnowledgeFunction();
  if (knowledgeTest) {
    console.log('\n🎉 所有测试通过！知识库功能正常工作');
  } else {
    console.log('\n⚠️ 知识库功能有问题，需要进一步调试');
  }
}

main().catch(console.error);
