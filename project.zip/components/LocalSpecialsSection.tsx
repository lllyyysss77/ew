
import React, { useState } from 'react';
import { SpecialItem } from '../types';
import { Icon } from './common/Icon';
import { getReliableImage } from '../services/geminiService';

// Mock Data for "Fengwuzhi"
// Updated to use getReliableImage for AI-generated visuals
const mockSpecials: SpecialItem[] = [
  {
    id: 's1',
    title: '东里红菇',
    category: '特产',
    priceOrTime: '¥120/斤',
    imageUrl: getReliableImage('wild red mushroom forest nature food photography'),
    description: '生长在深山密林中的野生红菇，营养丰富，煲汤鲜美无比。每年夏秋季节限量供应，是馈赠亲友的佳品。'
  },
  {
    id: 's2',
    title: '油桐花蜜',
    category: '特产',
    priceOrTime: '¥50/罐',
    imageUrl: getReliableImage('golden honey jar white flowers background'),
    description: '采集自东里村千亩油桐花海，色泽金黄，口感清甜，带有淡淡的花香。具有润肺止咳、美容养颜的功效。'
  },
  {
    id: 's3',
    title: '春季采茶',
    category: '活动',
    priceOrTime: '3月-5月',
    imageUrl: getReliableImage('tea plantation green leaves picking tea china'),
    description: '体验亲手采摘铁观音春茶的乐趣，学习传统制茶工艺，品尝第一口春茶的鲜爽。适合亲子家庭和摄影爱好者。'
  },
  {
    id: 's4',
    title: '迎龙灯会',
    category: '活动',
    priceOrTime: '农历正月',
    imageUrl: getReliableImage('traditional chinese dragon dance festival night fire'),
    description: '东里村最隆重的传统民俗活动，村民自发组织舞龙灯，祈求风调雨顺。现场锣鼓喧天，热闹非凡。'
  }
];

const LocalSpecialsSection: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<SpecialItem | null>(null);

  return (
    <div className="mt-8 mb-12 px-4 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
      <div className="flex items-baseline justify-between mb-4">
        <div>
           <h2 className="text-2xl font-serif-brand font-bold text-gray-800">风物志</h2>
           <p className="text-xs text-gray-500 mt-1 tracking-widest font-light">地道风物 人间烟火</p>
        </div>
        <button 
            onClick={() => setSelectedItem(mockSpecials[0])} // Open feed view
            className="text-xs text-teal-600 font-medium"
        >
            查看全部 &rarr;
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {mockSpecials.slice(0, 4).map(item => (
          <div 
            key={item.id}
            onClick={() => setSelectedItem(item)}
            className="relative aspect-square rounded-2xl overflow-hidden cursor-pointer group btn-press shadow-sm"
          >
            <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                onError={(e) => {
                    e.currentTarget.src = `https://placehold.co/600x600/e2e8f0/64748b?text=${item.title}`;
                }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
            
            {/* Badge */}
            <div className="absolute top-2 left-2">
                <span className={`
                    text-[10px] px-2 py-0.5 rounded-md backdrop-blur-md border border-white/20 text-white shadow-sm
                    ${item.category === '特产' ? 'bg-orange-500/80' : 'bg-teal-500/80'}
                `}>
                    {item.category}
                </span>
            </div>

            <div className="absolute bottom-3 left-3 text-white">
                <h4 className="font-bold text-sm tracking-wide shadow-black drop-shadow-sm">{item.title}</h4>
                <p className="text-[10px] opacity-90 font-light mt-0.5">{item.priceOrTime}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Full Screen Detail/Feed Modal */}
      {selectedItem && (
         <div className="fixed inset-0 z-[60] bg-paper flex flex-col animate-slide-up-sheet border-elegant">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-md p-4 shadow-sm flex items-center justify-between sticky top-0 z-10">
                <h3 className="font-serif-brand font-bold text-lg text-gray-800">东里风物</h3>
                <button 
                    onClick={() => setSelectedItem(null)}
                    className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-gray-200 transition"
                >
                    <Icon name="x" className="w-5 h-5" />
                </button>
            </div>

            {/* Feed Content with Scrollbar Hidden */}
            <div className="flex-grow overflow-y-auto p-4 space-y-6 pb-12 scrollbar-hide">
                {mockSpecials.map(item => (
                    <div key={item.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100">
                        <div className="h-48 relative">
                            <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                            <span className={`
                                absolute top-4 left-4 text-xs px-2 py-1 rounded-md backdrop-blur-md text-white
                                ${item.category === '特产' ? 'bg-orange-500/90' : 'bg-teal-500/90'}
                            `}>
                                {item.category}
                            </span>
                        </div>
                        <div className="p-5">
                            <div className="flex justify-between items-start mb-2">
                                <h4 className="text-xl font-bold text-gray-900 font-serif-brand">{item.title}</h4>
                                <span className="text-teal-600 font-bold text-sm bg-teal-50 px-2 py-1 rounded-lg">{item.priceOrTime}</span>
                            </div>
                            <p className="text-gray-600 text-sm leading-relaxed text-justify font-light">
                                {item.description}
                            </p>
                            <button className="mt-4 w-full py-2 rounded-xl border border-teal-500 text-teal-600 text-sm font-medium hover:bg-teal-50 transition">
                                咨询详情
                            </button>
                        </div>
                    </div>
                ))}
                <p className="text-center text-xs text-gray-400 py-4">—— 更多精彩 敬请期待 ——</p>
            </div>
         </div>
      )}
    </div>
  );
};

export default LocalSpecialsSection;