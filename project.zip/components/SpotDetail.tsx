
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Spot, VoiceResponse, RelatedKnowledge, NavigationInfo } from '../types';
import { Icon } from './common/Icon';
import { Spinner } from './common/Spinner';
import * as geminiService from '../services/geminiService';
import { decode, decodeAudioData } from '../utils/audioUtils';
import L from 'leaflet';

// Use CDN URLs for Leaflet icons to avoid module resolution issues
const markerIcon2x = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
const markerIcon = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const markerShadow = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: markerIcon2x,
    iconUrl: markerIcon,
    shadowUrl: markerShadow,
});

const NarrationPlayer: React.FC<{ spot: Spot }> = ({ spot }) => {
  const [narration, setNarration] = useState<VoiceResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSource, setPlaybackSource] = useState<'local' | 'api' | 'system' | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const localAudioRef = useRef<HTMLAudioElement | null>(null);
  const apiAudioContextRef = useRef<AudioContext | null>(null);
  const apiAudioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(typeof window !== 'undefined' ? window.speechSynthesis : null);

  const cleanupAudio = useCallback(() => {
    if (localAudioRef.current) {
      localAudioRef.current.pause();
      localAudioRef.current.currentTime = 0;
    }
    if (apiAudioSourceRef.current) {
      try { apiAudioSourceRef.current.stop(); } catch (e) {}
    }
    if (synthRef.current && synthRef.current.speaking) {
      synthRef.current.cancel();
    }
    setIsPlaying(false);
    setPlaybackSource(null);
  }, []);

  const handleFetchNarrationText = useCallback(async () => {
    setIsLoading(true);
    setErrorMessage(null);
    const cacheKey = `village_guide_narration_${spot.name}`;
    try {
      const cachedData = localStorage.getItem(cacheKey);
      if (cachedData) {
        try {
            setNarration(JSON.parse(cachedData).data);
            return;
        } catch(e) {
            console.warn("Cache parse error, refetching");
        }
      }
      const result = await geminiService.voiceInteraction(spot.name);
      setNarration(result);
      localStorage.setItem(cacheKey, JSON.stringify({ data: result }));
    } catch (error) {
      console.error("Failed to fetch narration text:", error);
      setNarration({ text: `欢迎来到${spot.name}。`, audio_base_64: "", need_manual_input: false });
    } finally {
      setIsLoading(false);
    }
  }, [spot.name]);

  useEffect(() => {
    handleFetchNarrationText();
    return cleanupAudio;
  }, [handleFetchNarrationText, cleanupAudio]);

  const playApiAudio = async (base64: string) => {
    try {
      if (!apiAudioContextRef.current || apiAudioContextRef.current.state === 'closed') {
        apiAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      if (apiAudioContextRef.current.state === 'suspended') {
        await apiAudioContextRef.current.resume();
      }
      const audioBytes = decode(base64);
      const buffer = await decodeAudioData(audioBytes, apiAudioContextRef.current, 24000, 1);
      
      const source = apiAudioContextRef.current.createBufferSource();
      source.buffer = buffer;
      source.connect(apiAudioContextRef.current.destination);
      source.onended = () => { setIsPlaying(false); setPlaybackSource(null); };
      source.start(0);
      apiAudioSourceRef.current = source;
      setIsPlaying(true);
      setPlaybackSource('api');
      return true;
    } catch (err) {
      return false;
    }
  };

  const playBrowserTTS = () => {
    if (narration?.text && synthRef.current) {
        try {
            synthRef.current.cancel();
            const utterance = new SpeechSynthesisUtterance(narration.text);
            const voices = synthRef.current.getVoices();
            utterance.voice = voices.find(v => v.lang === 'zh-CN') || voices.find(v => v.lang.startsWith('zh')) || null;
            utterance.onend = () => { setIsPlaying(false); setPlaybackSource(null); };
            utterance.onerror = (e) => { 
                setIsPlaying(false); 
                if (e.error !== 'interrupted' && e.error !== 'canceled') {
                    setErrorMessage("语音播放中断"); 
                }
            };
            synthRef.current.speak(utterance);
            setIsPlaying(true);
            setPlaybackSource('system');
        } catch (e) {
             setIsPlaying(false);
             setErrorMessage("无法启动语音");
        }
    } else {
        setErrorMessage("暂无可用语音");
    }
  };

  const handlePlayPause = async () => {
    if (isPlaying) {
      cleanupAudio();
      return;
    }
    setErrorMessage(null);

    const tryFallback = async () => {
        if (narration?.audio_base_64) {
            const success = await playApiAudio(narration.audio_base_64);
            if (success) return;
        }
        playBrowserTTS();
    }

    if (spot.audioUrl) {
      if (!localAudioRef.current) {
        localAudioRef.current = new Audio(spot.audioUrl);
        localAudioRef.current.onended = () => { setIsPlaying(false); setPlaybackSource(null); };
        localAudioRef.current.onerror = async () => {
          tryFallback();
        };
      }
      localAudioRef.current.play().then(() => {
        setIsPlaying(true);
        setPlaybackSource('local');
      }).catch(e => {
          tryFallback();
      });
      return;
    }
    tryFallback();
  };
  
  if (isLoading) {
      return (
          <div className="bg-teal-50/80 border border-solid border-teal-200 rounded-xl p-4 mt-4 flex justify-center items-center h-[92px] glass">
              <Spinner size="sm" /><span className="ml-3 text-teal-800/80 text-sm">正在生成导游词...</span>
          </div>
      )
  }

  if (!narration) return null;

  return (
    <div className="bg-white/90 backdrop-blur border border-teal-100 rounded-2xl p-4 mt-4 space-y-3 animate-fade-in-up shadow-premium-sm">
      <div className="flex items-center space-x-3">
        <button 
            onClick={handlePlayPause} 
            className={`w-12 h-12 flex-shrink-0 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 btn-press
                ${isPlaying ? 'bg-orange-500 text-white' : 'bg-teal-600 text-white hover:bg-teal-700'}
            `}
            title={isPlaying ? "暂停语音播放" : "播放语音介绍"}
            aria-label={isPlaying ? "暂停语音播放" : "播放语音介绍"}
        >
          <Icon name={isPlaying ? 'pause' : 'play'} className="w-6 h-6" />
        </button>
        <div className="flex-grow flex flex-col justify-center h-12">
             <div className="flex items-center justify-between mb-1">
                 <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-teal-800">语音导览</span>
                    {playbackSource === 'api' && isPlaying && <Icon name="upload" className="w-3 h-3 text-teal-500" title="云端语音" />}
                    {playbackSource === 'system' && isPlaying && <span className="text-[9px] bg-gray-200 text-gray-600 px-1.5 rounded">系统语音</span>}
                 </div>
                 <span className="text-[10px] text-gray-400">{isPlaying ? '播放中...' : '点击播放'}</span>
             </div>
             <div className="h-6 bg-teal-50 rounded-lg flex items-center px-2 space-x-1 overflow-hidden relative">
                 {isPlaying ? (
                     [...Array(20)].map((_, i) => ( <div key={i} className="w-1 bg-teal-400 rounded-full animate-pulse" style={{ height: `${Math.random() * 100}%`, animationDuration: `${0.5 + Math.random() * 0.5}s` }}></div> ))
                 ) : (
                     errorMessage ? (
                        <div className="text-[10px] text-red-500 flex items-center w-full truncate animate-fade-in">
                            <Icon name="x" className="w-3 h-3 mr-1" />
                            {errorMessage}
                        </div>
                     ) : (
                        <div className="w-full h-1 bg-teal-200 rounded-full"></div>
                     )
                 )}
             </div>
        </div>
      </div>
      <div>
        <p className="text-sm text-teal-900/80 leading-relaxed font-light">{narration.text}</p>
      </div>
    </div>
  );
};

const Modal: React.FC<{ title: string; isLoading: boolean; children: React.ReactNode; onClose: () => void; }> = ({ title, isLoading, children, onClose }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-black/50 backdrop-blur-sm animate-fade-in" onClick={onClose}></div>
    <div className="relative bg-white rounded-2xl shadow-premium-xl max-w-lg w-full animate-fade-in-up" role="dialog" aria-modal="true">
      <header className="p-4 border-b border-gray-200 flex justify-between items-center bg-stone-50 rounded-t-2xl">
        <h2 className="font-bold text-lg text-gray-800 font-serif-brand">{title}</h2>
        <button 
          onClick={onClose} 
          className="text-gray-400 hover:text-gray-700 transition btn-press" 
          title="关闭对话框"
          aria-label="关闭对话框"
        >
          <Icon name="x" className="w-5 h-5" />
        </button>
      </header>
      <main className="p-6 max-h-[60vh] overflow-y-auto scrollbar-hide">
        {isLoading ? <div className="flex justify-center items-center h-32"><Spinner /></div> : children}
      </main>
    </div>
  </div>
);

const PostcardModal: React.FC<{ spot: Spot; imageUrl: string; onClose: () => void }> = ({ spot, imageUrl, onClose }) => {
    const [filter, setFilter] = useState('none');
    const [customImage, setCustomImage] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    const filters = [
        { id: 'none', name: '原图', class: '' },
        { id: 'sepia', name: '复古', class: 'sepia' },
        { id: 'grayscale', name: '黑白', class: 'grayscale' },
        { id: 'lomo', name: 'LOMO', class: 'contrast-125 saturate-150' },
    ];

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                if (event.target?.result) setCustomImage(event.target.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleAIGenerate = () => {
        const newUrl = geminiService.getReliableImage(spot.name + " illustration art " + Date.now());
        setCustomImage(newUrl);
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-black/70 backdrop-blur-md animate-fade-in" onClick={onClose}></div>
            <div className="relative bg-white p-4 pb-6 rounded-none shadow-2xl w-full max-w-lg transform rotate-1 animate-fade-in-up">
                <div className="aspect-[3/4] w-full bg-gray-100 mb-3 overflow-hidden relative group">
                    <img 
                      src={customImage || imageUrl} 
                      alt={spot.name} 
                      className={`w-full h-full object-cover transition-all duration-500 ${filters.find(f => f.id === filter)?.class}`}
                      onError={(e) => {
                        e.currentTarget.onerror = null; 
                        e.currentTarget.src = geminiService.getReliableImage("暂无图片");
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-60 pointer-events-none"></div>
                    
                    {/* Overlay Controls */}
                    <div className="absolute top-2 right-2 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                         <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="bg-black/50 text-white p-2 rounded-full backdrop-blur-sm hover:bg-black/70"
                            title="拍照/上传"
                         >
                             <Icon name="camera" className="w-4 h-4" />
                         </button>
                         <button 
                            onClick={handleAIGenerate}
                            className="bg-black/50 text-white p-2 rounded-full backdrop-blur-sm hover:bg-black/70"
                            title="AI生成配图"
                         >
                             <span className="text-[10px] font-bold">AI</span>
                         </button>
                    </div>

                    <div className="absolute bottom-4 left-4 right-4 text-white text-center pointer-events-none">
                         <p className="font-serif-brand text-2xl font-bold tracking-widest drop-shadow-md">{spot.postcardText || spot.name}</p>
                    </div>
                </div>

                <div className="flex justify-center space-x-2 mb-4 overflow-x-auto pb-1">
                    {filters.map(f => (
                        <button 
                            key={f.id}
                            onClick={() => setFilter(f.id)}
                            className={`text-[10px] px-3 py-1 rounded-full border transition-all whitespace-nowrap
                                ${filter === f.id ? 'bg-gold text-paper border-gold' : 'bg-paper text-ink-light border-gold-dim'}
                            `}
                        >
                            {f.name}
                        </button>
                    ))}
                </div>
                
                <div className="flex justify-between items-end px-2 mb-4 border-t border-gray-100 pt-3">
                    <div>
                        <h3 className="font-bold text-gray-800 text-lg">{spot.name}</h3>
                        <p className="text-xs text-gray-400 uppercase tracking-wider">Dongli Village · Memory</p>
                    </div>
                    <div className="w-10 h-10 bg-gray-800 flex items-center justify-center text-white text-[8px] text-center leading-tight opacity-80">
                        扫码<br/>听故事
                    </div>
                </div>

                <div className="text-center">
                     <button 
                        onClick={() => alert("请长按上方图片保存到手机相册")}
                        className="bg-teal-600 text-white px-8 py-2.5 rounded-full text-sm shadow-lg hover:bg-teal-700 transition flex items-center justify-center mx-auto space-x-2 btn-press"
                     >
                         <Icon name="upload" className="w-4 h-4" />
                         <span>保存到相册</span>
                     </button>
                </div>

                <button 
                  onClick={onClose} 
                  className="absolute -top-4 -right-4 bg-white rounded-full p-2 text-gray-500 shadow-lg border hover:text-gray-800 transition"
                  title="关闭拍照"
                  aria-label="关闭拍照功能"
                >
                    <Icon name="x" className="w-5 h-5" />
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleFileChange}
                  title="选择图片文件"
                  aria-label="选择图片文件上传"
                />
            </div>
        </div>
    );
};

export interface SpotDetailProps {
  spot: Spot;
  onBack: () => void;
  onNext: () => void;
  navigationInfo: NavigationInfo | null;
  isNavLoading: boolean;
  onAskAI?: (question: string) => void;
  currentSpotIndex?: number;
  totalSpots?: number;
}

const SpotDetail: React.FC<SpotDetailProps> = ({ spot, onBack, onNext, navigationInfo, isNavLoading, onAskAI, currentSpotIndex = 0, totalSpots = 1 }) => {
  const [modalState, setModalState] = useState<{ type: 'knowledge'; data: any } | null>(null);
  const [isModalLoading, setIsModalLoading] = useState(false);
  const [showNarration, setShowNarration] = useState(false);
  const [showPostcard, setShowPostcard] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  const spotImageUrl = spot.imageUrl || geminiService.getReliableImage(spot.imagePrompt + spot.name);

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    e.currentTarget.onerror = null;
    e.currentTarget.src = geminiService.getReliableImage("Fallback");
  };

  // Monitor network status for offline support
  useEffect(() => {
    const handleStatusChange = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleStatusChange);
    window.addEventListener('offline', handleStatusChange);
    return () => {
        window.removeEventListener('online', handleStatusChange);
        window.removeEventListener('offline', handleStatusChange);
    };
  }, []);

  const handleKnowledgeClick = async () => {
    setModalState({ type: 'knowledge', data: null });
    setIsModalLoading(true);
    try {
      const result = await geminiService.getRelatedKnowledge(spot.name);
      setModalState({ type: 'knowledge', data: result });
    } catch (error) {
      alert("获取关联知识失败，请稍后重试。");
      setModalState(null);
    } finally {
      setIsModalLoading(false);
    }
  };

  useEffect(() => {
    // Initialize map immediately if online
    if (isOnline && mapContainerRef.current) {
        if (!mapInstanceRef.current) {
             const [lngStr, latStr] = spot.coord.split(',');
             const lng = parseFloat(lngStr);
             const lat = parseFloat(latStr);
             
             if (!isNaN(lat) && !isNaN(lng)) {
                 const mapInstance = L.map(mapContainerRef.current, {
                     zoomControl: false,
                     dragging: false, // Make it more of a static preview initially
                     scrollWheelZoom: false,
                     touchZoom: false,
                     doubleClickZoom: false
                 }).setView([lat, lng], 16);
                 
                 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                     attribution: '&copy; OpenStreetMap contributors'
                 }).addTo(mapInstance);
                 
                 const customMarkerIcon = L.icon({
                     iconUrl: markerIcon,
                     iconRetinaUrl: markerIcon2x,
                     shadowUrl: markerShadow,
                     iconSize: [25, 41],
                     iconAnchor: [12, 41],
                     popupAnchor: [1, -34],
                     shadowSize: [41, 41]
                 });

                 L.marker([lat, lng], { icon: customMarkerIcon }).addTo(mapInstance);
                 
                 mapInstanceRef.current = mapInstance;
                 
                 setTimeout(() => mapInstance.invalidateSize(), 100);
             }
        } else {
             // Update view if map already exists
             const [lngStr, latStr] = spot.coord.split(',');
             const lng = parseFloat(lngStr);
             const lat = parseFloat(latStr);
             if (!isNaN(lat) && !isNaN(lng)) {
                 mapInstanceRef.current.setView([lat, lng], 16);
             }
        }
    }
  }, [spot, isOnline]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
        if (mapInstanceRef.current) {
            mapInstanceRef.current.remove();
            mapInstanceRef.current = null;
        }
    }
  }, []);

  return (
    <div className="animate-fade-in-up" key={spot.id}>
      <div className="bg-white rounded-t-3xl shadow-premium-xl overflow-hidden mt-4 min-h-[80vh] relative">
        <div className="relative h-72 w-full bg-gray-100">
          <img src={spotImageUrl} alt={spot.name} className="w-full h-full object-cover animate-fade-in" onError={handleImageError} />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none"></div>
          
          <button onClick={onBack} className="absolute top-4 left-4 bg-white/20 backdrop-blur-md rounded-full p-2 text-white hover:bg-white/40 transition-all z-10 border border-white/30 btn-press" title="返回" aria-label="返回">
            <Icon name="arrow-left" className="w-6 h-6" />
          </button>

          <div className="absolute bottom-6 left-6 right-16 text-white pointer-events-none">
            <h2 className="text-3xl font-serif-brand font-bold drop-shadow-lg tracking-wide">{spot.name}</h2>
            <div className="h-1 w-10 bg-teal-500 my-2 rounded-full"></div>
            <p className="text-sm drop-shadow text-white/90 font-light line-clamp-1">{spot.intro_short}</p>
          </div>
        </div>

        <div className="p-6 pt-10 bg-white relative pb-32">
          {spot.tags && spot.tags.length > 0 && (
             <div className="flex flex-wrap gap-2 mb-6">
                 {spot.tags.map((tag, i) => (
                     <button 
                         key={i} 
                         onClick={() => onAskAI && onAskAI(`${spot.name}的${tag}`)} 
                         className="px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-medium border border-teal-100 hover:bg-teal-100 transition-colors tag-button"
                         data-spot={spot.name}
                         data-keyword={tag}
                         data-category="tag"
                     >
                         ✨ {tag}
                     </button>
                 ))}
             </div>
          )}

          <div className="text-gray-700 leading-relaxed space-y-4 mb-8 font-light text-justify">
            {spot.intro_txt.split('\n').map((p, i) => <p key={i}>{p || '\u00A0'}</p>)}
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <button 
                onClick={handleKnowledgeClick} 
                className="group relative overflow-hidden rounded-2xl p-4 bg-orange-50 border border-orange-100 shadow-sm hover:shadow-md transition btn-press"
                data-spot={spot.name}
                data-keyword="历史"
                data-category="knowledge"
            >
                <div className="relative z-10 flex flex-col items-center">
                    <Icon name="book-open" className="w-8 h-8 text-orange-500 mb-2" />
                    <span className="font-bold text-orange-900">关联知识</span>
                    <span className="text-xs text-orange-600/70 mt-1">AI 深度解读</span>
                </div>
            </button>

            <button 
                onClick={() => setShowPostcard(true)} 
                className="group relative overflow-hidden rounded-2xl p-4 bg-blue-50 border border-blue-100 shadow-sm hover:shadow-md transition btn-press"
                data-spot={spot.name}
                data-keyword="拍照"
                data-category="photo"
            >
                <div className="relative z-10 flex flex-col items-center">
                    <Icon name="camera" className="w-8 h-8 text-blue-500 mb-2" />
                    <span className="font-bold text-blue-900">生成明信片</span>
                    <span className="text-xs text-blue-600/70 mt-1">定格美好瞬间</span>
                </div>
            </button>
          </div>

          {/* Embedded Map Section with Offline Fallback */}
          <div className="mb-8 rounded-2xl overflow-hidden border border-gray-100 shadow-sm relative group h-48 bg-stone-100">
              {isOnline ? (
                  <>
                    <div ref={mapContainerRef} className="w-full h-full z-0" />
                    <a 
                        href={geminiService.getGoogleMapsUrl(spot.coord, spot.name)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="absolute bottom-3 right-3 bg-white/90 backdrop-blur text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm flex items-center space-x-1 text-teal-700 hover:bg-teal-50 transition z-10"
                    >
                        <Icon name="map" className="w-3 h-3" />
                        <span>打开导航</span>
                    </a>
                    <div className="absolute top-3 left-3 bg-white/80 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-gray-500 pointer-events-none">
                        当前位置
                    </div>
                  </>
              ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-stone-50 text-stone-500">
                      <Icon name="location" className="w-10 h-10 mb-3 text-stone-300" />
                      <p className="text-sm font-bold text-stone-600">当前处于离线模式</p>
                      <p className="text-xs mt-2 leading-relaxed max-w-[80%]">
                          {navigationInfo?.route_text || "请沿主路直行，留意路标指引前往下一个景点。"}
                      </p>
                      <button onClick={() => window.location.reload()} className="mt-3 text-xs text-teal-600 font-bold border border-teal-200 px-3 py-1 rounded-full hover:bg-teal-50">
                          刷新地图
                      </button>
                  </div>
              )}
          </div>

          {!showNarration ? (
            <div className="relative rounded-2xl overflow-hidden shadow-lg btn-press cursor-pointer" onClick={() => setShowNarration(true)}>
                <div className="absolute inset-0 bg-gradient-to-r from-teal-600 to-cyan-700"></div>
                <div className="relative p-5 flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                            <Icon name="microphone" className="w-5 h-5 text-white" />
                        </div>
                        <div className="text-white">
                            <p className="font-bold text-lg">听小A 讲述景点故事</p>
                            <p className="text-xs opacity-80">沉浸式语音讲解</p>
                        </div>
                    </div>
                    <Icon name="play" className="w-6 h-6 text-white opacity-80" />
                </div>
            </div>
          ) : (
            <NarrationPlayer spot={spot} />
          )}
        </div>
      </div>
      
      {/* Tour Progress Footer - Updated Max Width */}
      <div className="fixed bottom-0 left-0 right-0 max-w-2xl mx-auto bg-white/70 backdrop-blur-xl border-t border-gray-200/50 p-4 px-6 rounded-t-2xl shadow-sm z-30 flex items-center justify-between pb-8">
          <div className="flex flex-col">
             <span className="text-[10px] text-gray-400 uppercase tracking-wider mb-1.5">
                 游玩进度 {currentSpotIndex + 1}/{totalSpots}
             </span>
             <div className="flex space-x-1.5">
                 {Array.from({ length: totalSpots }).map((_, i) => (
                     <div 
                        key={i} 
                        className={`h-1.5 rounded-full transition-all duration-300 ${
                            i < currentSpotIndex ? 'w-2 bg-teal-200' : 
                            i === currentSpotIndex ? 'w-6 bg-teal-500' : 'w-2 bg-gray-100'
                        }`}
                     ></div>
                 ))}
             </div>
          </div>
          <button onClick={onNext} className="flex items-center space-x-2 bg-stone-800 text-white px-6 py-3 rounded-full shadow-lg hover:bg-black transition-all active:scale-95 btn-press">
             <span className="text-sm font-bold">
                 {currentSpotIndex + 1 === totalSpots ? '完成打卡' : '前往下一站'}
             </span>
             <Icon name={currentSpotIndex + 1 === totalSpots ? 'check-circle' : 'arrow-left'} className={`w-4 h-4 ${currentSpotIndex + 1 === totalSpots ? '' : 'transform rotate-180'}`} />
          </button>
      </div>

      {modalState && (
        <Modal title={modalState.type === 'knowledge' ? '关联知识' : '详细信息'} isLoading={isModalLoading} onClose={() => setModalState(null)}>
          {modalState.data && (
             <div className="space-y-4">
                {modalState.data.imageUrl && <img src={modalState.data.imageUrl} alt="" className="w-full h-40 object-cover rounded-xl" />}
                <h3 className="font-bold text-xl">{modalState.data.title}</h3>
                <p className="text-gray-600">{modalState.data.content}</p>
             </div>
          )}
        </Modal>
      )}
      
      {showPostcard && <PostcardModal spot={spot} imageUrl={spotImageUrl} onClose={() => setShowPostcard(false)} />}
    </div>
  );
};

export default SpotDetail;
