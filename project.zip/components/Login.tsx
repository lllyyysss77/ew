import React, { useState } from 'react';
import { Spinner } from './common/Spinner';
import { Icon } from './common/Icon';

const bgLandingImg = "https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?q=80&w=1920&auto=format&fit=crop";
const avatarA = "https://api.dicebear.com/9.x/micah/svg?seed=Felix&backgroundColor=b6e3f4";

interface LoginProps {
  onLogin: (userId: string) => void;
  onAdminClick: () => void;
  geoLoading: boolean;
  geoError: GeolocationPositionError | null;
}

const GeolocationStatus: React.FC<{ loading: boolean; error: GeolocationPositionError | null }> = ({ loading, error }) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center text-xs text-teal-600/50 mt-6 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
        <Spinner size="sm" />
        <span className="ml-2">正在定位，准备为您开启旅程...</span>
      </div>
    );
  }
  if (error) {
    return (
      <div className="flex items-center justify-center text-xs text-teal-600/50 mt-6 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
        <Icon name="location" className="w-3 h-3 mr-1" />
        <span>欢迎访问，请稍后选择您的定位</span>
      </div>
    );
  }
  return <div className="h-[34px] mt-6"></div>; 
};

const Login: React.FC<LoginProps> = ({ onLogin, onAdminClick, geoLoading, geoError }) => {
  const handleLogin = (loginType: 'wechat' | 'alipay') => {
    const openid = `${loginType}_${Math.random().toString(36).substring(2, 10)}`;
    const userId = `user_${openid.slice(-8)}`;
    onLogin(userId);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-teal-50/30 via-white to-blue-50/20 p-6 relative overflow-hidden">
      {/* Subtle gradient borders like original */}
      <div className="fixed top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-teal-200/40 to-transparent"></div>
      <div className="fixed bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-teal-200/40 to-transparent"></div>
      <div className="fixed top-0 bottom-0 left-0 w-px bg-gradient-to-b from-transparent via-teal-200/30 to-transparent"></div>
      <div className="fixed top-0 bottom-0 right-0 w-px bg-gradient-to-b from-transparent via-teal-200/30 to-transparent"></div>
      
      {/* Login Card - 确保清晰可见 */}
      <div className="relative bg-white/90 backdrop-blur-md p-8 rounded-3xl max-w-md w-full animate-fade-in-up border border-white/80 shadow-premium-lg">
        
        {/* Header */}
        <div className="mb-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-teal-100 to-teal-200 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-teal-300/50 shadow-sm">
                 <Icon name="map" className="w-8 h-8 text-teal-700" />
            </div>
            <h1 className="text-2xl font-serif-brand font-bold text-teal-900 mb-2">村官智能体</h1>
            <p className="text-sm text-teal-700">AI 伴您探索乡土之美</p>
        </div>

        {/* Login Actions */}
        <div className="space-y-3 mb-6">
          <button
            onClick={() => handleLogin('wechat')}
            className="w-full flex items-center justify-center space-x-3 py-3.5 rounded-2xl bg-white/80 hover:bg-white border border-green-400/30 hover:border-green-400/50 text-green-700 transition-all group shadow-sm hover:shadow-md"
          >
             <div className="w-5 h-5 bg-green-500/20 rounded-lg flex items-center justify-center">
                <Icon name="chat-bubble" className="w-3 h-3 text-green-600" />
             </div>
             <span className="text-sm font-medium">微信一键游</span>
             <Icon name="arrow-left" className="w-4 h-4 text-green-400/60 group-hover:text-green-500 transform rotate-180 ml-auto" />
          </button>

          <button
            onClick={() => handleLogin('alipay')}
            className="w-full flex items-center justify-center space-x-3 py-3.5 rounded-2xl bg-white/80 hover:bg-white border border-blue-400/30 hover:border-blue-400/50 text-blue-700 transition-all group shadow-sm hover:shadow-md"
          >
             <div className="w-5 h-5 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <Icon name="bag" className="w-3 h-3 text-blue-600" />
             </div>
             <span className="text-sm font-medium">支付宝登录</span>
             <Icon name="arrow-left" className="w-4 h-4 text-blue-400/60 group-hover:text-blue-500 transform rotate-180 ml-auto" />
          </button>
        </div>

        <GeolocationStatus loading={geoLoading} error={geoError} />

         <div className="mt-8 pt-6 border-t border-teal-100/30">
            <button 
                onClick={onAdminClick}
                className="w-full text-xs text-teal-600/50 hover:text-teal-700/70 flex items-center justify-center transition-colors py-2 rounded-xl hover:bg-teal-50/40"
            >
                <Icon name="users" className="w-3 h-3 mr-1" />
                村民/管理员入口
            </button>
        </div>
      </div>
      
      <p className="absolute bottom-6 text-[10px] text-teal-500/30">Powered by Gemini AI · 公益助农</p>
    </div>
  );
};

export default Login;