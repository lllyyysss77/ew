import React, { useState } from 'react';
import { Icon } from './common/Icon';

// 历史人物数据
const FIGURES = [
  {
    id: 'li-tiemin',
    name: '李铁民',
    title: '永春华侨革命党第一笔',
    honor: '革命先驱',
    imageUrl: '/agent/img/李铁民.jpg',
    shortBio: '以笔为枪，唤醒民众。永春华侨革命的杰出代表。',
    birthDeath: '1898 - 1956',
    fullBio: '李铁民（1898—1956），原名李赋京，福建永春人。归侨，著名侨领。早年在南洋加入同盟会，创办报刊，撰写大量文章宣传反清革命思想，被誉为"永春华侨革命党第一笔"。一生致力于维护华侨权益，支持祖国革命与建设。他的文章如匕首投枪，直刺敌人心脏，鼓舞了无数爱国华侨的热血，为祖国的独立和解放事业做出了不可磨灭的贡献。',
    tags: ['华侨领袖', '笔杆子', '抗日救亡']
  },
  {
    id: 'song-yuan',
    name: '宋渊源',
    title: '辛亥革命猛将',
    honor: '辛亥功臣',
    imageUrl: '/agent/img/宋渊源.jpg',
    shortBio: '投笔从戎，驰骋沙场，为推翻帝制立下赫赫战功。',
    birthDeath: '1881 - 1961',
    fullBio: '宋渊源（1881—1961），字子清，福建永春人。早年加入中国同盟会，追随孙中山先生投身辛亥革命。他性格豪爽，作战勇猛，在光复福建的战役中立下赫赫战功。民国成立后，致力于家乡建设与教育事业，是永春著名的革命先驱。他一生铁骨铮铮，正气浩然，为捍卫共和、反对军阀混战而奔走呼号。',
    tags: ['辛亥革命', '军事将领', '铁骨铮铮']
  },
  {
    id: 'zheng-chengkuai',
    name: '郑成快',
    title: '辛亥革命二等奖章获得者',
    honor: '二等勋章',
    imageUrl: '/agent/img/郑成快.jpg',
    shortBio: '功勋卓著，荣获二等奖章，忠诚于革命事业。',
    birthDeath: 'Unknown',
    fullBio: '郑成快，福建永春东里人。辛亥革命时期积极响应号召，投身革命队伍。在光复福州等战役中表现英勇，冲锋在前，不畏牺牲。因其在推翻清朝统治、建立民国过程中的杰出贡献，荣获辛亥革命二等奖章，是东里村的骄傲。他忠诚于革命事业，为建立共和立下了不可磨灭的功绩。',
    tags: ['辛亥革命', '勋章获得者', '忠诚']
  },
  {
    id: 'zheng-yuzhi',
    name: '郑玉指',
    title: '获孙中山亲颁"旌义状"',
    honor: '毁家纾难',
    imageUrl: '/agent/img/郑玉指.jpg',
    shortBio: '爱国侨胞，支持革命，毁家纾难，义薄云天。',
    birthDeath: '1851 - 1929',
    fullBio: '郑玉指（1851—1929年），字绳摇，永春仙夹东里村人。早年出洋到马来亚的槟榔屿谋生，后经商发达。1906年加入中国同盟会，成为槟榔屿分会第一批会员。他毁家纾难，多次慷慨捐输巨资支持孙中山的革命活动。1912年，孙中山亲颁"旌义状"，表彰其"宣扬大义，不遗余力"。他的故事是海外赤子爱国情怀的最高写照，展现了永春华侨为民族复兴不计得失的高尚情操。',
    tags: ['爱国华侨', '毁家纾难', '旌义状']
  }
];

const FigureCard: React.FC<{
  figure: typeof FIGURES[0];
  onClick: (figure: typeof FIGURES[0]) => void;
  index: number;
}> = ({ figure, onClick, index }) => {
  return (
    <div
      className={`relative bg-paper rounded-xl overflow-hidden shadow-premium hover:shadow-premium-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1 fade-in-up-slow ${
        index === 0 ? 'animation-delay-100' : 
        index === 1 ? 'animation-delay-200' : 
        index === 2 ? 'animation-delay-300' : 
        index === 3 ? 'animation-delay-400' : 
        'animation-delay-500'
      }`}
      onClick={() => onClick(figure)}
    >
      <div className="aspect-w-4 aspect-h-5 overflow-hidden">
        <img
          src={figure.imageUrl}
          alt={figure.name}
          className="w-full h-full object-cover sepia-[0.2] hover:sepia-0 transition-all duration-700"
        />
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs px-2 py-1 bg-red/10 text-red rounded-full border border-red/20">
            {figure.honor}
          </span>
          {figure.birthDeath && (
            <span className="text-xs text-ink-light">{figure.birthDeath}</span>
          )}
        </div>
        <h3 className="text-lg font-serif font-bold text-ink mb-1">{figure.name}</h3>
        <p className="text-sm text-ink-light">{figure.title}</p>
      </div>
    </div>
  );
};

const FigureDetail: React.FC<{
  figure: typeof FIGURES[0];
  onClose: () => void;
}> = ({ figure, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 animate-fade-in"
        onClick={onClose}
      ></div>

      {/* Modal Content */}
      <div className="relative bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden animate-fade-in-up z-10">
        {/* Header with image background */}
        <div className="relative h-80 overflow-hidden">
          <img
            src={figure.imageUrl}
            alt={figure.name}
            className="w-full h-full object-cover sepia-[0.4] contrast-110"
          />

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/30 backdrop-blur-md p-2 rounded-full text-white hover:bg-black/50 transition-colors border border-white/20"
            title="关闭"
            aria-label="关闭"
          >
            <Icon name="x" className="w-5 h-5" />
          </button>

          {/* Title overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
            <div className="flex items-center space-x-3 mb-3">
              <span className="px-3 py-1 bg-red/80 backdrop-blur-sm text-xs tracking-widest uppercase rounded-full border border-white/20">
                {figure.honor}
              </span>
              {figure.birthDeath && (
                <span className="text-sm opacity-80 font-serif">{figure.birthDeath}</span>
              )}
            </div>
            <h1 className="text-4xl font-serif font-bold tracking-wider mb-2">{figure.name}</h1>
            <p className="text-lg opacity-90 font-serif italic">{figure.title}</p>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 bg-white max-h-[calc(90vh-20rem)] overflow-y-auto scrollbar-hide">
          {/* Biography */}
          <div className="prose prose-stone max-w-none">
            <p className="text-gray-700 leading-relaxed text-justify first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:mr-3 first-letter:float-left first-letter:text-red-600">
              {figure.fullBio}
            </p>
          </div>

          {/* Tags section */}
          <div className="mt-10 pt-6 border-t border-gray-200">
            <h4 className="text-center text-sm text-gray-500 mb-4 tracking-widest font-serif">—— 历史印记 ——</h4>
            <div className="flex flex-wrap justify-center gap-2">
              {figure.tags.map(tag => (
                <span
                  key={tag}
                  className="px-4 py-2 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 text-amber-800 text-sm rounded-full font-serif shadow-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Decorative seal */}
          <div className="mt-8 text-center">
            <div className="inline-block w-16 h-16 bg-red-600 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-white text-xs font-serif">丹心</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const HallOfFame: React.FC = () => {
  const [selectedFigure, setSelectedFigure] = useState<typeof FIGURES[0] | null>(null);

  return (
    <div className="min-h-screen bg-paper bg-texture">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-sm border-b border-gold/20">
        <div className="container py-4 flex items-center justify-between">
          <h1 className="text-2xl font-serif font-bold text-ink">永春 · 丹心</h1>
          <p className="text-sm text-ink-light italic">追寻先辈足迹，重温峥嵘岁月</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-serif font-bold text-ink mb-4">人物志 · 卷一</h2>
          <div className="w-24 h-1 bg-gold mx-auto mb-6"></div>
          <p className="text-ink-light max-w-2xl mx-auto">
            永春华侨革命志士，以血肉之躯铸就民族脊梁，以赤子丹心照亮前行之路。他们的故事，是历史的见证，更是精神的传承。
          </p>
        </div>

        {/* Figure Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {FIGURES.map((figure, index) => (
            <FigureCard
              key={figure.id}
              figure={figure}
              index={index}
              onClick={setSelectedFigure}
            />
          ))}
        </div>

        {/* Footer Note */}
        <div className="text-center py-8">
          <p className="text-xs text-ink-muted font-serif">—— 更多历史人物整理中 ——</p>
        </div>
      </main>

      {/* Figure Detail Modal */}
      {selectedFigure && (
        <FigureDetail
          figure={selectedFigure}
          onClose={() => setSelectedFigure(null)}
        />
      )}
    </div>
  );
};

export default HallOfFame;
