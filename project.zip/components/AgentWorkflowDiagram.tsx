
import React, { useEffect } from 'react';
import { Icon } from './common/Icon';

const avatarA = "https://api.dicebear.com/9.x/micah/svg?seed=Felix&backgroundColor=b6e3f4";
const avatarB = "https://api.dicebear.com/9.x/micah/svg?seed=Aneka&backgroundColor=c0aede";
const avatarC = "https://api.dicebear.com/9.x/micah/svg?seed=Mila&backgroundColor=ffdfbf";
const avatarD = "https://api.dicebear.com/9.x/micah/svg?seed=Robert&backgroundColor=f0f0f0";

const agentData: Record<'A' | 'B' | 'C' | 'D', { id: string; name: string; avatar: string; color: string }> = {
  A: { id: 'A', name: '前台·小A', avatar: avatarA, color: 'text-amber-600' },
  B: { id: 'B', name: '讲解·阿义', avatar: avatarB, color: 'text-emerald-600' },
  C: { id: 'C', name: '特产·阿红', avatar: avatarC, color: 'text-orange-600' },
  D: { id: 'D', name: '纪念·小D', avatar: avatarD, color: 'text-blue-600' },
};

interface WorkflowStep {
  agentId: 'A' | 'B' | 'C' | 'D';
  action: string;
}

const workflowSteps: WorkflowStep[] = [
  { agentId: 'A', action: '匹配景点' },
  { agentId: 'B', action: '识别与讲解' },
  { agentId: 'C', action: '推荐特产' },
  { agentId: 'D', action: '生成纪念册' },
];

const WorkflowArrow: React.FC = () => (
  <div className="flex-1 flex items-center justify-center px-1 mt-5 opacity-30">
    <Icon name="chevron-down" className="w-4 h-4 transform -rotate-90 text-teal-600" />
  </div>
);

const AgentWorkflowDiagram: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-white/60 to-teal-50/30 border border-teal-50 rounded-2xl p-4 shadow-sm">
      <div className="flex items-start justify-between space-x-0">
        {workflowSteps.map((step, index) => {
          const agent = agentData[step.agentId];
          return (
            <React.Fragment key={step.agentId}>
              <div className="flex flex-col items-center text-center w-1/4 group cursor-default">
                {/* Avatar Image */}
                <div className="relative w-12 h-12 md:w-14 md:h-14 mb-2 transition-transform transform group-hover:scale-110 duration-300 filter drop-shadow-sm">
                   <img 
                      src={agent.avatar} 
                      alt={agent.name}
                      className="w-full h-full object-contain"
                   />
                </div>
                
                <p className={`font-bold text-xs ${agent.color} mb-0.5`}>{step.action}</p>
              </div>
              {index < workflowSteps.length - 1 && <WorkflowArrow />}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default AgentWorkflowDiagram;
