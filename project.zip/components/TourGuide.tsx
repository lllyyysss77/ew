
import React, { useState, useEffect, useCallback } from 'react';
import { Spot, NavigationInfo, Route } from '../types';
import * as geminiService from '../services/geminiService';
import SpotList from './SpotList';
import SpotDetail from './SpotDetail';
import { Spinner } from './common/Spinner';
import { Icon } from './common/Icon';
import FloatingAgentBar from './FloatingAgentBar';
// import HallOfFame from './HallOfFame'; // 已移除，使用独立纪念专辑页面
import LocalSpecialsSection from './LocalSpecialsSection';

const avatarA = "https://api.dicebear.com/9.x/micah/svg?seed=Felix&backgroundColor=b6e3f4";

interface TourGuideProps {
  userId: string;
  onLogout: () => void;
  coordinates: { lat: number; lng: number } | null;
  geoLoading: boolean;
  geoError: GeolocationPositionError | null;
}

// Mock Locations for Manual Positioning
const MOCK_LOCATIONS = [
    { name: '村口 (默认位置)', lat: 22.6789, lng: 113.2345 }, // Using the default fallback coords
    { name: '永春辛亥革命纪念馆', lat: 25.23411225, lng: 118.20524049 },
    { name: '仙灵瀑布 (自然生态)', lat: 25.238000, lng: 118.201000 },
    { name: '豆磨古寨 (俯瞰全村)', lat: 25.239000, lng: 118.202000 },
    { name: '东里水库', lat: 25.23773823, lng: 118.20442982 },
    { name: '集庆廊桥', lat: 25.233800, lng: 118.203500 },
];

const LocationPickerModal: React.FC<{ 
    onSelect: (loc: {lat: number, lng: number}) => void; 
    onClose: () => void 
}> = ({ onSelect, onClose }) => (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={onClose}></div>
        <div className="relative bg-white rounded-2xl w-full max-w-lg overflow-hidden animate-fade-in-up shadow-2xl">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-stone-50">
                <h3 className="font-bold text-primary-800 flex items-center">
                    <Icon name="location" className="w-5 h-5 mr-2 text-teal-600" />
                    选择当前位置
                </h3>
                <button 
                  onClick={onClose} 
                  className="p-1 rounded-full hover:bg-gray-200 transition"
                  title="关闭位置选择"
                  aria-label="关闭位置选择"
                >
                    <Icon name="x" className="w-5 h-5 text-gray-500" />
                </button>
            </div>
            <div className="p-2 max-h-[60vh] overflow-y-auto">
                {MOCK_LOCATIONS.map((loc, idx) => (
                    <button
                        key={idx}
                        onClick={() => onSelect({ lat: loc.lat, lng: loc.lng })}
                        className="w-full text-left p-4 hover:bg-teal-50 rounded-xl transition-colors border-b border-gray-50 last:border-0 group"
                    >
                        <div className="font-medium text-primary-800 group-hover:text-teal-700">{loc.name}</div>
                        <div className="text-xs text-gray-400 mt-1 font-mono">
                            {loc.lng.toFixed(4)}, {loc.lat.toFixed(4)}
                        </div>
                    </button>
                ))}
            </div>
        </div>
    </div>
);

const TourGuide: React.FC<TourGuideProps> = ({ userId: _userId, onLogout: _onLogout, coordinates: initialCoords, geoLoading, geoError: _geoError }) => {
  const [routes, setRoutes] = useState<Route[] | null>(null);
  const [selectedSpot, setSelectedSpot] = useState<Spot | null>(null);
  const [selectedSpotCategory, setSelectedSpotCategory] = useState<Route['category'] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [navigationInfo, setNavigationInfo] = useState<NavigationInfo | null>(null);
  const [isNavLoading, setIsNavLoading] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  // New state for bridging interaction between SpotDetail/Modal and AgentBar
  const [activeQuestion, setActiveQuestion] = useState<string | null>(null);
  
  // Manual location State
  const [currentCoords, setCurrentCoords] = useState<{ lat: number; lng: number } | null>(initialCoords);
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [showAvatarTooltip, setShowAvatarTooltip] = useState(false);

  // Handle Intent Navigation from WelcomeModal or other places
  useEffect(() => {
    const handleIntent = (event: Event) => {
        const e = event as CustomEvent;
        const intent = e.detail;
        // console.log("Navigating to intent:", intent);
        
        // Reset view if needed
        if (selectedSpot) {
            setSelectedSpot(null);
            setSelectedSpotCategory(null);
        }

        setTimeout(() => {
            if (intent === 'tour') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } else if (intent === 'culture') {
                document.getElementById('section-celebrity')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                console.log('导航到纪念专辑链接区域');
            } else if (intent === 'specials') {
                document.getElementById('section-specials')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else if (intent === 'market') {
                // Scroll to specials (which might contain market items) AND ask agent
                document.getElementById('section-specials')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                setActiveQuestion('推荐特产');
            }
        }, 100); // Slight delay to allow state updates/rendering
    };

    window.addEventListener('navigation-intent', handleIntent);
    return () => window.removeEventListener('navigation-intent', handleIntent);
  }, [selectedSpot]);

  // Update internal coords when prop changes (e.g. real GPS update)
  useEffect(() => {
      if (initialCoords) {
          setCurrentCoords(initialCoords);
      }
  }, [initialCoords]);

  const fetchRoutes = useCallback(async () => {
    // Use current manual coords or default fallback
    const userCoord = currentCoords ? `${currentCoords.lng},${currentCoords.lat}` : "113.2345,22.6789"; 
    try {
      setError(null);
      setIsLoading(true);
      const data = await geminiService.getRoutes(userCoord, "东里村");
      setRoutes(data.routes);
    } catch (err) {
      setError("无法加载景点信息，请检查网络后重试。");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [currentCoords]);


  useEffect(() => {
    if (!geoLoading) {
      fetchRoutes();
    }
  }, [geoLoading, fetchRoutes]);

  // Optimized Scroll Listener using requestAnimationFrame and Passive listener
  useEffect(() => {
    let ticking = false;
    
    const handleScroll = () => {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                if (window.scrollY > 300) {
                    setShowScrollTop(true);
                } else {
                    setShowScrollTop(false);
                }
                ticking = false;
            });
            ticking = true;
        }
    };

    // Use { passive: true } to improve scrolling performance
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const fetchNavigation = async () => {
      if (selectedSpot && currentCoords) {
        setIsNavLoading(true);
        setNavigationInfo(null);
        try {
          const userCoord = `${currentCoords.lng},${currentCoords.lat}`;
          const navData = await geminiService.getNavigationRoute(userCoord, selectedSpot.name, selectedSpot.coord);
          setNavigationInfo(navData);
        } catch (err) {
          console.error("Failed to fetch navigation info:", err);
          setNavigationInfo(null); // Ensure it's null on error
        } finally {
          setIsNavLoading(false);
        }
      } else {
        setNavigationInfo(null);
      }
    };
    fetchNavigation();
  }, [selectedSpot, currentCoords]);

  const handleSelectSpot = (spot: Spot, category: Route['category']) => {
    setSelectedSpot(spot);
    setSelectedSpotCategory(category);
     window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToList = () => {
    setSelectedSpot(null);
    setSelectedSpotCategory(null);
  };

  const handleNextSpot = () => {
      if (!selectedSpot || !routes) return;
      
      let currentRoute = null;
      let currentIndex = -1;

      // Find the route containing the current spot
      for (const route of routes) {
          const idx = route.spots.findIndex(s => s.id === selectedSpot.id);
          if (idx !== -1) {
              currentRoute = route;
              currentIndex = idx;
              break;
          }
      }

      if (currentRoute && currentIndex !== -1) {
          // Check if there is a next spot
          if (currentIndex < currentRoute.spots.length - 1) {
              const nextSpot = currentRoute.spots[currentIndex + 1];
              handleSelectSpot(nextSpot, currentRoute.category);
          } else {
              // End of route, go back to list
              handleBackToList();
          }
      } else {
          handleBackToList();
      }
  };

  const scrollToTop = () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handler for asking AI from SpotDetail tags
  const handleAskAI = (question: string) => {
      setActiveQuestion(question);
  };
  
  const handleLocationSelect = (loc: { lat: number; lng: number }) => {
      setCurrentCoords(loc);
      setShowLocationPicker(false);
      // Trigger re-fetch of routes or just simulate refresh
      setIsLoading(true);
      setTimeout(() => {
          setIsLoading(false);
          // Optional: Show toast "Located to X"
      }, 500);
  };
  
  const handleAvatarClick = () => {
      setShowAvatarTooltip(true);
      setTimeout(() => setShowAvatarTooltip(false), 2000);
  };

  const renderContent = () => {
    if (isLoading || geoLoading) {
      return <div className="flex flex-col items-center justify-center h-[calc(100vh-10rem)]"><Spinner /><p className="mt-4 text-gray-600 text-sm font-light animate-pulse">{geoLoading ? '正在获取您的位置信息，以便为您提供更精准的导览服务...' : 'AI正在为您规划专属路线...'}</p></div>;
    }
    if (error) {
      return <div className="text-center p-8 text-red-500">{error}<button onClick={fetchRoutes} className="mt-4 bg-teal-500 text-white px-4 py-2 rounded">重试</button></div>;
    }

    if (routes) {
      return (
        <div className="p-4 space-y-8 pb-24 min-h-screen">
          {selectedSpot ? (
            <SpotDetail 
              spot={selectedSpot} 
              onBack={handleBackToList}
              onNext={handleNextSpot}
              navigationInfo={navigationInfo}
              isNavLoading={isNavLoading}
              onAskAI={handleAskAI}
            />
          ) : (
            <>
              <div id="section-routes">
                <h2 className="text-2xl font-serif-brand font-bold text-primary-800 px-2 mb-4">推荐路线</h2>
                <SpotList
                  routes={routes}
                  onSelectSpot={handleSelectSpot}
                  selectedSpotId={(selectedSpot as Spot | null)?.id || null}
                />
              </div>
              {/* Hall of Fame Section - 链接到独立纪念专辑页面 */}
              <div id="section-celebrity" style={{ contentVisibility: 'auto' }} data-section="celebrity" className="py-12">
                 <div className="text-center">
                    <h2 className="text-2xl font-serif-brand font-bold text-primary-800 px-2 mb-6">永春 · 丹心</h2>
                    <div className="w-24 h-1 bg-gold mx-auto mb-6"></div>
                    <p className="text-gray-600 max-w-2xl mx-auto mb-8">
                        追寻先辈足迹，重温峥嵘岁月。永春华侨革命志士的丰功伟绩，值得铭记与传承。
                    </p>
                    <a 
                        href="http://localhost:3001" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-full hover:from-amber-600 hover:to-orange-600 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                    >
                        <span className="font-serif">访问纪念专辑</span>
                        <Icon name="arrow-left" className="w-4 h-4 transform rotate-180" />
                    </a>
                    <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
                        {[
                            { name: '李铁民', imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E6%9D%8E%E9%93%81%E6%B0%91.jpg?e=1763669601&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:vshvF183VpJxjmV69Qy3ac2wngs=' },
                            { name: '宋渊源', imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E5%AE%8B%E6%B8%8A%E6%BA%90.jpg?e=1763669775&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:4TorkmcfnwZqC0G3v8ZAdG4MCuI=' },
                            { name: '郑成快', imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E9%83%91%E6%88%90%E5%BF%AB.jpg-50?e=1763669651&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:_4fjPmV1QiyEVlScPDO5VjN0yBg=' },
                            { name: '郑玉指', imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E9%83%91%E7%8E%89%E6%8C%87.jpg?e=1763669706&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:nAe770mU7HZ29Qiz1BOj7Uaw1Mg=' }
                        ].map((person, index) => (
                            <div key={index} className="text-center p-3 bg-primary-50 rounded-lg border border-primary-200 hover:shadow-md transition-shadow cursor-pointer">
                                <div className="w-12 h-12 rounded-full mx-auto mb-2 overflow-hidden">
                                    <img 
                                        src={person.imageUrl} 
                                        alt={person.name} 
                                        className="w-full h-full object-cover sepia-[0.2]"
                                        onError={(e) => {
                                            // 图片加载失败时显示首字母
                                            const target = e.target as HTMLImageElement;
                                            target.style.display = 'none';
                                            const parent = target.parentElement;
                                            if (parent) {
                                                parent.innerHTML = `<span class="text-primary-700 font-bold text-sm">${person.name[0]}</span>`;
                                            }
                                        }}
                                    />
                                </div>
                                <p className="text-xs text-primary-800 font-medium">{person.name}</p>
                            </div>
                        ))}
                    </div>
                 </div>
              </div>
              {/* Local Specials Section */}
              <div id="section-specials" style={{ contentVisibility: 'auto' }} data-section="specials">
                 <LocalSpecialsSection />
              </div>
            </>
          )}
        </div>
      );
    }

    return null;
  };

  return (
    // Removed overflow-hidden to allow fixed modals to render correctly over everything
    <div className="max-w-2xl mx-auto bg-gradient-to-br from-teal-50/20 via-white to-blue-50/10 min-h-screen relative">
       {/* Ambient Background Animation */}
       <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[30%] bg-gold/10 rounded-full blur-3xl animate-pulse-dot pointer-events-none"></div>
       <div className="absolute bottom-[10%] right-[-10%] w-[60%] h-[40%] bg-red/5 rounded-full blur-3xl animate-pulse-dot pointer-events-none" style={{ animationDelay: '2s' }}></div>

      <header className="sticky top-0 z-30 bg-white/30 backdrop-blur-sm flex items-center justify-between p-4 border-b border-teal-100/20 will-change-transform">
        {selectedSpot ? (
            <button
                onClick={handleBackToList}
                className="text-gold hover:text-gold-dark p-2 rounded-full hover:bg-gold/10 transition-colors btn-press flex items-center justify-center"
                title="返回首页"
            >
                <Icon name="home" className="w-6 h-6" />
            </button>
        ) : (
            <button 
                onClick={() => setShowLocationPicker(true)} 
                className="text-gold hover:bg-gold/10 p-2 rounded-full btn-press flex flex-col items-center" 
                title="切换定位"
            >
                <Icon name="location" className="w-6 h-6"/>
                <span className="text-[9px] font-medium">切换定位</span>
            </button>
        )}
        
        <div className="flex flex-col items-center relative">
            <div 
                className="flex items-center space-x-2 cursor-pointer p-1 rounded-lg hover:bg-gold/10 transition-colors" 
                onClick={handleAvatarClick}
            >
                 <img 
                    src={avatarA} 
                    alt="Avatar" 
                    className="w-8 h-8 rounded-full bg-gold/20 shadow-sm border border-gold-dim object-cover"
                 />
                 <h1 className="text-lg serif-text font-bold text-ink tracking-wide">村官智能体 · 东里村</h1>
            </div>
            
            {/* Avatar Interaction Tooltip */}
            {showAvatarTooltip && (
                <div className="absolute top-full mt-2 bg-gray-800 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap animate-fade-in z-50 shadow-lg">
                    功能即将上线哦 ✨
                    <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-gray-800 rotate-45"></div>
                </div>
            )}
        </div>

        {selectedSpot ? (
             <button 
                onClick={handleNextSpot}
                className="text-teal-600 hover:text-teal-800 p-2 rounded-lg hover:bg-teal-50 transition-colors btn-press flex items-center space-x-0.5"
             >
                 <span className="text-xs font-bold">下一站</span>
                 <Icon name="arrow-left" className="w-4 h-4 transform rotate-180" />
             </button>
        ) : (
             <div className="w-8 h-8"></div>
        )}
      </header>
      <main className="relative min-h-[calc(100vh-80px)]">
        {renderContent()}
      </main>
      
       {/* Scroll to Top Button */}
       {showScrollTop && !selectedSpot && (
        <button
            onClick={scrollToTop}
            className="fixed bottom-24 right-4 z-30 bg-white/80 backdrop-blur text-teal-600 p-3 rounded-full shadow-lg border border-teal-100 hover:bg-teal-50 transition-all animate-fade-in-up"
            style={{ marginBottom: '70px' }} // Stack above agent button
            title="返回顶部"
            aria-label="返回页面顶部"
        >
            <Icon name="arrow-left" className="w-5 h-5 transform rotate-90" />
        </button>
      )}

      {!isLoading && (
          // Directly render FloatingAgentBar without fixed wrapper, passing bottom offset
          <FloatingAgentBar 
            spot={selectedSpot} 
            activeQuestion={activeQuestion}
            onQuestionHandled={() => setActiveQuestion(null)}
            bottomOffset={selectedSpot ? 80 : 0} 
          />
      )}
      
      {/* Location Picker Modal */}
      {showLocationPicker && (
          <LocationPickerModal 
            onSelect={handleLocationSelect} 
            onClose={() => setShowLocationPicker(false)} 
          />
      )}
    </div>
  );
};

export default TourGuide;
