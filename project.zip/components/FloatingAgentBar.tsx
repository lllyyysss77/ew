
import React, { useState, useEffect, useRef } from 'react';
import { Spot, VoiceResponse } from '../types';
import * as geminiService from '../services/geminiService';
import { Icon } from './common/Icon';
import { Spinner } from './common/Spinner';
import { decode, decodeAudioData } from '../utils/audioUtils';
import { pageAwareness, PageEvent, AgentInsight } from '../services/pageAwareness';

interface ChatMessage {
    sender: 'user' | 'ai';
    text: string;
    audio?: string;
}

const ChatBubble: React.FC<{ message: ChatMessage; isPlaying: boolean; onPlay: () => void }> = ({ message, isPlaying, onPlay }) => {
  if (message.sender === 'user') {
    return (
      <div className="flex justify-end animate-fade-in-up animation-duration-fast">
        <div className="bg-teal-500 text-white rounded-lg rounded-br-none px-4 py-3 shadow-premium-sm max-w-[85%]">
          {message.text}
        </div>
      </div>
    );
  }
  return (
    <div className="flex justify-start animate-fade-in-up animation-duration-fast">
      <div className="bg-white text-gray-800 rounded-lg rounded-bl-none px-4 py-3 shadow-premium-sm max-w-[85%]">
        <p>{message.text}</p>
        <button 
            onClick={onPlay}
            className={`mt-2 flex items-center space-x-1 text-xs px-2 py-1 rounded-full border transition-colors
                ${isPlaying ? 'bg-gold/20 border-gold text-gold-dark animate-pulse' : 'bg-paper border-gold-dim text-ink-light hover:bg-gold/10 hover:text-gold'}
            `}
        >
            <Icon name={isPlaying ? 'pause' : 'play'} className="w-3 h-3" />
            <span>{isPlaying ? '正在播放...' : '播放语音'}</span>
        </button>
      </div>
    </div>
  );
};

interface FloatingAgentBarProps {
    spot: Spot | null;
    activeQuestion?: string | null;
    onQuestionHandled?: () => void;
    bottomOffset?: number; // New prop for dynamic positioning
}

const FloatingAgentBar: React.FC<FloatingAgentBarProps> = ({ spot, activeQuestion, onQuestionHandled, bottomOffset = 0 }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  
  const [playingIndex, setPlayingIndex] = useState<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(typeof window !== 'undefined' ? window.speechSynthesis : null);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  
  // 页面感知相关状态
  const [pageInsights, setPageInsights] = useState<AgentInsight>(pageAwareness.getCurrentInsights());
  const [showContextTip, setShowContextTip] = useState(false);
  const [hasGreeted, setHasGreeted] = useState(false);
  const [showBubbles, setShowBubbles] = useState(false);

  // 基于页面感知的智能建议问题
  const getSuggestedQuestions = () => {
    const baseQuestions = [
      "这个景点的历史背景是什么？",
      "最佳游览时间是多久？",
      "拍照的最佳位置在哪里？"
    ];

    // 根据用户兴趣和当前页面状态生成个性化问题
    const contextualQuestions: string[] = [];
    
    if (pageInsights.currentSpot) {
      contextualQuestions.push(`讲讲${pageInsights.currentSpot}的故事`);
      contextualQuestions.push(`${pageInsights.currentSpot}有什么特色？`);
    }

    if (pageInsights.activeSection) {
      if (pageInsights.activeSection.includes('celebrity')) {
        contextualQuestions.push("介绍几位东里村的名人");
        contextualQuestions.push("名人堂有什么看点？");
      } else if (pageInsights.activeSection.includes('specials')) {
        contextualQuestions.push("推荐一些当地特产");
        contextualQuestions.push("哪里可以买到正宗特产？");
      }
    }

    if (pageInsights.recentKeywords.length > 0) {
      const topKeyword = pageInsights.recentKeywords[0];
      if (topKeyword.includes('拍照') || topKeyword.includes('风景')) {
        contextualQuestions.push("哪里拍照最好看？");
      } else if (topKeyword.includes('历史') || topKeyword.includes('文化')) {
        contextualQuestions.push("这里有什么历史故事？");
      } else if (topKeyword.includes('美食') || topKeyword.includes('特产')) {
        contextualQuestions.push("有什么特色美食推荐？");
      }
    }

    // 合并并去重，最多返回6个问题
    return [...new Set([...contextualQuestions, ...baseQuestions])].slice(0, 6);
  };

  const suggestedQuestions = getSuggestedQuestions();

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
      if (activeQuestion && !isLoading) {
          if (!isOpen) setIsOpen(true);
          handleSendMessage(activeQuestion);
          if (onQuestionHandled) onQuestionHandled();
      }
  }, [activeQuestion]);

  // 首次访问打招呼功能
  useEffect(() => {
    // 检查是否是首次访问（使用localStorage记录）
    const hasVisitedToday = localStorage.getItem('agent_greeted_today');
    const today = new Date().toDateString();
    
    if (!hasVisitedToday || hasVisitedToday !== today) {
      // 延迟2秒后显示打招呼，让用户先看到页面
      const greetTimer = setTimeout(() => {
        if (!hasGreeted) {
          setIsOpen(true);
          const greetingMessage = {
            sender: 'ai' as const,
            text: '您来啦～小A等您很久啦！我是今天的小小村官儿～ 我来为您服务🌟',
            audio: undefined
          };
          setMessages([greetingMessage]);
          setHasGreeted(true);
          
          // 触发气泡飘出特效
          setShowBubbles(true);
          setTimeout(() => setShowBubbles(false), 3500); // 3.5秒后隐藏气泡
          
          // 记录今天已经打过招呼
          localStorage.setItem('agent_greeted_today', today);
          
          // 跟踪打招呼事件
          pageAwareness.trackCustomEvent('interaction', {
            action: 'greeting',
            source: 'auto',
            timestamp: Date.now()
          });

          // 不再自动播放语音，避免冒犯用户
          // 用户需要主动点击语音按钮才会播放
        }
      }, 2000);

      return () => clearTimeout(greetTimer);
    }
  }, [hasGreeted]);

  // 页面感知订阅
  useEffect(() => {
    const unsubscribe = pageAwareness.subscribe((insights) => {
      setPageInsights(insights);
      
      // 检测到用户兴趣变化时的智能提示
      if (insights.recentKeywords.length > 0 && isOpen && !isLoading) {
        const latestKeyword = insights.recentKeywords[0];
        const shouldShowTip = Math.random() > 0.7; // 30%概率显示提示
        
        if (shouldShowTip && !showContextTip) {
          setShowContextTip(true);
          setTimeout(() => setShowContextTip(false), 5000);
        }
      }
    });

    return () => {
      unsubscribe();
      if (audioSourceRef.current) {
          try { audioSourceRef.current.stop(); } catch (e) {}
      }
      if (synthRef.current && synthRef.current.speaking) {
          synthRef.current.cancel();
      }
    };
  }, [isOpen, isLoading, showContextTip]);

  const getBestVoice = () => {
    if (!synthRef.current) return null;
    const voices = synthRef.current.getVoices();
    return voices.find(v => v.lang === 'zh-CN') || voices[0];
  };

  const handlePlayAudio = async (base64: string | undefined, text: string, index: number) => {
     if (audioSourceRef.current) {
         try { audioSourceRef.current.stop(); } catch (e) {}
         audioSourceRef.current = null;
     }
     if (synthRef.current) synthRef.current.cancel();
     
     if (playingIndex === index) {
         setPlayingIndex(null);
         return;
     }
     
     setPlayingIndex(index);

     if (base64) {
         try {
            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            if (audioContextRef.current.state === 'suspended') await audioContextRef.current.resume();
            
            const buffer = await decodeAudioData(decode(base64), audioContextRef.current, 24000, 1);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = buffer;
            source.connect(audioContextRef.current.destination);
            source.onended = () => setPlayingIndex(null);
            
            audioSourceRef.current = source;
            source.start(0);
            return;
         } catch (e) {
             console.warn("Audio play failed, falling back to TTS", e);
         }
     }

     if (synthRef.current) {
         const utterance = new SpeechSynthesisUtterance(text);
         const bestVoice = getBestVoice();
         if (bestVoice) utterance.voice = bestVoice;
         utterance.onend = () => setPlayingIndex(null);
         utterance.onerror = () => setPlayingIndex(null);
         synthRef.current.speak(utterance);
     }
  };

  const handleSendMessage = async (questionText?: string) => {
    const textToSend = questionText || inputValue;
    if (!textToSend.trim()) return;

    if (!questionText) setInputValue('');
    
    setMessages(prev => [...prev, { sender: 'user', text: textToSend }]);
    setIsLoading(true);

    try {
      const contextSpotName = spot?.name || '这个地方';
      const response: VoiceResponse = await geminiService.voiceInteraction(contextSpotName, textToSend);
      
      setMessages(prev => {
          const newMsgs = [...prev, { sender: 'ai' as const, text: response.text, audio: response.audio_base_64 }];
          // 不再自动播放语音，用户需要主动点击
          return newMsgs;
      });

    } catch (error) {
      setMessages(prev => [...prev, { sender: 'ai', text: '抱歉，我现在有点忙，请稍后再试。' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMicClick = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("您的浏览器暂不支持语音功能");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'zh-CN';
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
        setIsListening(true);
        setInputValue('');
    };
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                finalTranscript += event.results[i][0].transcript;
            } else {
                finalTranscript += event.results[i][0].transcript;
            }
        }
        setInputValue(finalTranscript);
    };
    recognition.onerror = (event: any) => {
        setIsListening(false);
        if (event.error === 'not-allowed') {
             alert("无法访问麦克风。");
        }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  if (!isOpen) {
    return (
      <>
        {/* 气泡飘出特效 */}
        {showBubbles && (
          <div className="bubble-container">
            <div className="bubble bubble-small"></div>
            <div className="bubble bubble-medium"></div>
            <div className="bubble bubble-large"></div>
          </div>
        )}
        
        <div 
          className="fixed right-4 z-40 animate-fade-in-up animation-delay-medium bottom-offset-default" 
          style={{ '--bottom-offset': `${bottomOffset}px` } as React.CSSProperties}
        >
          <button
            onClick={() => setIsOpen(true)}
            className="bg-gradient-primary text-white rounded-full shadow-premium-xl p-3 flex items-center justify-center transition-all transform hover:scale-105 glass-card floating-button-large"
            title="打开AI助手"
            aria-label="打开AI助手"
          >
            <Icon name="chat-bubble" className="w-7 h-7 text-white" />
          </button>
        </div>
      </>
    );
  }

  return (
    <div 
        className="fixed right-4 z-50 chat-panel bg-surface-elevated rounded-2xl shadow-premium-xl flex flex-col animate-fade-in-up border-accent glass bottom-offset-small"
        style={{ '--bottom-offset': `${bottomOffset}px` } as React.CSSProperties}
    >
      <header className="flex-shrink-0 p-4 bg-surface-elevated rounded-t-2xl flex items-center justify-between border-b border-light">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full flex items-center justify-center bg-gradient-primary shadow-lg">
            <Icon name="chat-bubble" className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="font-bold text-primary">村官智能体</p>
            <p className="text-xs text-muted">您的专属AI导游</p>
          </div>
        </div>
        <button 
          onClick={() => setIsOpen(false)} 
          className="text-muted hover:text-secondary" 
          title="关闭对话框"
          aria-label="关闭对话框"
        >
          <Icon name="x" className="w-5 h-5" />
        </button>
      </header>

      <main className="flex-grow p-4 space-y-4 overflow-y-auto scrollbar-hide bg-surface-subtle">
        {/* 页面感知提示 */}
        {showContextTip && pageInsights.recentKeywords.length > 0 && (
          <div className="p-3 bg-gradient-to-r from-primary-50 to-accent-light border border-accent rounded-lg text-sm animate-fade-in-up">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
              <p className="font-semibold text-accent-dark">智能感知</p>
            </div>
            <p className="text-xs text-primary">
              我注意到您对「{pageInsights.recentKeywords[0]}」感兴趣，有什么想了解的吗？
            </p>
          </div>
        )}

        {/* 当前上下文显示 */}
        {(pageInsights.currentSpot || pageInsights.activeSection) && (
          <div className="p-2 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-700">
            <div className="flex items-center space-x-2">
              <Icon name="eye" className="w-3 h-3" />
              <span>
                当前关注: {pageInsights.currentSpot || 
                  (pageInsights.activeSection?.replace('section-', '').replace('-', ' ') || '首页')}
              </span>
            </div>
          </div>
        )}

        <div className="p-3 bg-teal-50 border border-teal-200 rounded-lg text-sm text-teal-800">
          <p className="font-semibold mb-2">您可以问：</p>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((q, i) => (
              <button key={i} onClick={() => handleSendMessage(q)} className="text-xs bg-white border border-teal-300 rounded-full px-3 py-1 hover:bg-teal-100 transition">
                {q}
              </button>
            ))}
          </div>
        </div>
        {messages.map((msg, index) => (
          <ChatBubble key={index} message={msg} isPlaying={playingIndex === index} onPlay={() => handlePlayAudio(msg.audio, msg.text, index)} />
        ))}
        {isLoading && <div className="bg-white rounded-lg px-4 py-3 shadow-sm"><Spinner size="sm"/></div>}
        <div ref={chatEndRef} />
      </main>

      <footer className="flex-shrink-0 p-3 bg-white border-t rounded-b-2xl">
        <div className="flex items-center space-x-2">
          <button
            onClick={handleMicClick}
            className={`p-2 rounded-full transition-all flex-shrink-0 ${isListening ? 'bg-red-100 text-red-500 animate-pulse' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            title={isListening ? "停止录音" : "开始语音输入"}
            aria-label={isListening ? "停止录音" : "开始语音输入"}
          >
             <Icon name="microphone" className="w-5 h-5" />
          </button>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={isListening ? "正在聆听..." : "输入您的问题..."}
            title={isListening ? "正在聆听中..." : "输入您的问题并按回车发送"}
            disabled={isLoading}
            className="flex-grow bg-gray-100 rounded-lg px-4 py-2.5 text-gray-800 border-transparent focus:ring-2 focus:ring-teal-400 outline-none transition-all"
          />
          <button 
            onClick={() => handleSendMessage()} 
            disabled={isLoading || !inputValue.trim()} 
            className="w-10 h-10 rounded-lg flex items-center justify-center bg-teal-500 text-white"
            title="发送消息"
            aria-label="发送消息"
          >
            <Icon name="arrow-left" className="w-5 h-5 transform rotate-90" />
          </button>
        </div>
      </footer>
    </div>
  );
};

export default FloatingAgentBar;
