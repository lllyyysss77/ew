
import React, { useState, useEffect } from 'react';
import { Spot, Agent, AgentColorClasses, Route } from '../types';
import AgentPresenter from './AgentPresenter';
import MapView from './MapView';
import { Spinner } from './common/Spinner';
import { Icon } from './common/Icon';
import * as geminiService from '../services/geminiService';

const AGENT_A_IMAGE_URL = "/agent/img/A.png";
const AGENT_B_IMAGE_URL = "https://api.dicebear.com/9.x/micah/svg?seed=Aneka&backgroundColor=c0aede";
const AGENT_C_IMAGE_URL = "https://api.dicebear.com/9.x/micah/svg?seed=Mila&backgroundColor=ffdfbf";
const AGENT_D_IMAGE_URL = "https://api.dicebear.com/9.x/micah/svg?seed=Robert&backgroundColor=f0f0f0";

const agentColors: Record<string, AgentColorClasses> = {
  A: { bg: 'bg-gradient-primary', border: 'border-accent', text: 'text-white', shadow: 'hover:shadow-premium-lg', iconBg: 'bg-accent' },
  B: { bg: 'bg-gradient-subtle', border: 'border-accent-light', text: 'text-accent-dark', shadow: 'hover:shadow-diffuse', iconBg: 'bg-accent-light' },
  C: { bg: 'bg-gradient-glass', border: 'border-accent', text: 'text-accent-dark', shadow: 'hover:shadow-premium', iconBg: 'bg-accent' },
  RED: { bg: 'bg-gradient-subtle', border: 'border-accent-light', text: 'text-primary', shadow: 'hover:shadow-diffuse', iconBg: 'bg-accent' },
  ECO: { bg: 'bg-gradient-glass', border: 'border-accent', text: 'text-accent-dark', shadow: 'hover:shadow-premium', iconBg: 'bg-accent' },
  FOOD: { bg: 'bg-gradient-subtle', border: 'border-accent-light', text: 'text-primary', shadow: 'hover:shadow-diffuse', iconBg: 'bg-accent' },
};

export const agents: Agent[] = [
  { id: 'A', name: '小A村官儿', description: '我是您的专属AI导游', icon: 'user', imageUrl: AGENT_A_IMAGE_URL, interactionType: 'system', actionText: '', colorClasses: agentColors.A },
  { id: 'RED', name: '红导阿义', description: '红色文化专属导游', icon: 'book-open', imageUrl: AGENT_B_IMAGE_URL, interactionType: 'photo', actionText: '拍照讲解', colorClasses: agentColors.RED },
  { id: 'ECO', name: '生态阿绿', description: '自然生态专属导游', icon: 'map', imageUrl: AGENT_B_IMAGE_URL, interactionType: 'photo', actionText: '拍照讲解', colorClasses: agentColors.ECO },
  { id: 'FOOD', name: '美食探味家', description: '带你品尝地道美味', icon: 'price-tag', imageUrl: AGENT_C_IMAGE_URL, interactionType: 'photo', actionText: '拍照讲解', colorClasses: agentColors.FOOD },
  { id: 'B', name: 'B 景点解说智能体', description: '支持语音/文字/拍照互动', icon: 'academic-cap', imageUrl: AGENT_B_IMAGE_URL, interactionType: 'photo', actionText: '拍照讲解', colorClasses: agentColors.B },
  { id: 'C', name: '特产推荐员', description: '为您搜罗好物', icon: 'bag', imageUrl: AGENT_C_IMAGE_URL, interactionType: 'shop', actionText: '查找好物', colorClasses: agentColors.C },
];

const getGeolocationErrorMessage = (error: GeolocationPositionError): string => {
  switch (error.code) {
    case 1: return "已拒绝位置权限。";
    case 2: return "无法定位, 请检查网络/GPS。";
    case 3: return "获取位置超时。";
    default: return "未知错误。";
  }
};

interface PresenterModeProps {
  routes: Route[] | null;
  activeSpot: Spot | null;
  activeSpotCategory: Route['category'] | null;
  onSelectSpotFromMap: (spot: Spot | null) => void;
  isLoading: boolean;
  error: string | null;
  geoError: GeolocationPositionError | null;
}

const PresenterMode: React.FC<PresenterModeProps> = ({ routes, activeSpot, activeSpotCategory, onSelectSpotFromMap, isLoading, error, geoError }) => {
  const [activeAgent, setActiveAgent] = useState<Agent>(agents.find(a => a.id === 'A')!);
  const [visualMode, setVisualMode] = useState<'map' | 'image'>('map');

  useEffect(() => {
    if (activeSpot && activeSpotCategory) {
      setVisualMode('image');
      let newAgentId: Agent['id'] = 'B'; // Fallback
      switch (activeSpotCategory) {
        case '历史文化': newAgentId = 'RED'; break;
        case '自然风景': newAgentId = 'ECO'; break;
        case '美食体验': newAgentId = 'FOOD'; break;
      }
      // Find the agent or fallback to B
      const targetAgent = agents.find(a => a.id === newAgentId) || agents.find(a => a.id === 'B')!;
      setActiveAgent(targetAgent);
    } else {
      setVisualMode('map');
      setActiveAgent(agents.find(a => a.id === 'A')!);
    }
  }, [activeSpot, activeSpotCategory]);

  const handleSwitchToAgentC = () => {
    setActiveAgent(agents.find(a => a.id === 'C')!);
  }

  if (isLoading) {
    return <div className="flex flex-col items-center justify-center h-[calc(100vh-5rem)]"><Spinner /><p className="mt-4 text-gray-600">正在加载导览数据...</p></div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">{error}</div>;
  }

  // Use getReliableImage instead of deprecated source.unsplash.com
  const activeSpotImageUrl = activeSpot ? geminiService.getReliableImage(activeSpot.imagePrompt) : '';

  return (
    <div className="flex flex-col h-[calc(100vh-88px)] overflow-hidden bg-surface">
      {/* Reduced map height to 20% to prioritize chat interface */}
      <div className="relative h-[20vh] flex-shrink-0 bg-surface-subtle border-b-4 border-white shadow-premium-sm">
        {geoError && (
          <div className="absolute top-0 left-0 right-0 bg-yellow-100 text-yellow-800 text-xs p-1 text-center z-50">
            {getGeolocationErrorMessage(geoError)}
          </div>
        )}
        
        {visualMode === 'map' ? (
           <MapView 
              routes={routes || []} 
              onSelectSpot={onSelectSpotFromMap} 
              activeSpotId={activeSpot?.id || null} 
           />
        ) : (
           <div className="relative w-full h-full">
              <img src={activeSpotImageUrl} alt={activeSpot?.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none"></div>
              <div className="absolute bottom-4 left-4 text-white">
                  <h2 className="text-2xl font-bold text-shadow">{activeSpot?.name}</h2>
                  <p className="text-sm opacity-90">{activeSpot?.intro_short}</p>
              </div>
              <button 
                onClick={() => onSelectSpotFromMap(null)}
                className="absolute top-4 right-4 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full backdrop-blur-sm transition"
                title="关闭详情"
                aria-label="关闭景点详情"
              >
                  <Icon name="x" className="w-5 h-5" />
              </button>
           </div>
        )}
      </div>

      <div className="flex-grow overflow-hidden bg-surface-elevated relative z-10 shadow-premium-lg -mt-4 rounded-t-3xl">
         <AgentPresenter 
            agent={activeAgent} 
            spot={activeSpot} 
            onSwitchToAgentC={handleSwitchToAgentC}
         />
      </div>
    </div>
  );
};

export default PresenterMode;
