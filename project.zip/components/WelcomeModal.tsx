
import React, { useState, useEffect } from 'react';
import { Icon } from './common/Icon';

const avatarA = "https://api.dicebear.com/9.x/micah/svg?seed=Felix&backgroundColor=b6e3f4";

interface WelcomeModalProps {
  onClose: () => void;
}

const WelcomeModal: React.FC<WelcomeModalProps> = ({ onClose }) => {
  const [currentDate, setCurrentDate] = useState('');
  const [greeting, setGreeting] = useState('');
  const [weatherIcon, setWeatherIcon] = useState<'sun' | 'moon'>('sun');
  const [weatherText, setWeatherText] = useState('');

  useEffect(() => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    setCurrentDate(now.toLocaleDateString('zh-CN', options));

    const hour = now.getHours();
    if (hour >= 5 && hour < 12) {
      setGreeting('早上好！一日之计在于晨。');
      setWeatherIcon('sun');
      setWeatherText('晴空万里 24°C');
    } else if (hour >= 12 && hour < 18) {
      setGreeting('下午好！愿您有段惬意的时光。');
      setWeatherIcon('sun');
      setWeatherText('微风徐徐 28°C');
    } else {
      setGreeting('晚上好！乡村的夜空格外宁静。');
      setWeatherIcon('moon');
      setWeatherText('星河璀璨 20°C');
    }
  }, []);

  const handleNavigation = (intent: 'tour' | 'culture' | 'specials' | 'market') => {
      // Dispatch custom event for TourGuide to catch
      const event = new CustomEvent('navigation-intent', { detail: intent });
      window.dispatchEvent(event);
      onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/10 backdrop-blur-sm animate-fade-in" onClick={onClose}></div>
      <div className="relative bg-white/50 backdrop-blur-sm p-0 rounded-3xl max-w-lg w-full overflow-hidden animate-fade-in-up border border-white/40" style={{ animationDuration: '0.4s' }}>
        
        {/* Header Section */}
        <div className="h-20 bg-gradient-to-br from-teal-50/40 to-teal-100/30 relative p-3 flex flex-col justify-between border-b border-teal-100/20">
             <div className="absolute top-1 right-1 opacity-20">
                 <Icon name={weatherIcon} className="w-12 h-12 text-teal-500/50" />
             </div>
             <div className="text-teal-800/60 relative z-10">
                 <div className="flex items-center space-x-2 opacity-70 text-[10px] mb-1">
                     <Icon name="calendar" className="w-3 h-3" />
                     <span>{currentDate}</span>
                 </div>
                 <div className="flex items-center space-x-2 font-medium text-xs">
                     <span>{weatherText}</span>
                 </div>
             </div>
        </div>

        <div className="p-6 pt-6 relative bg-white/30">
            {/* Avatar */}
            <div className="absolute -top-6 left-4 w-12 h-12 bg-white/60 rounded-full p-0.5 overflow-hidden z-20 border border-white/50">
                <img 
                    src={avatarA} 
                    alt="AI Avatar" 
                    className="w-full h-full rounded-full object-cover"
                />
            </div>

            <h2 className="text-lg font-serif-brand font-bold text-teal-900/60 mb-1 mt-1">{greeting}</h2>
            <p className="text-teal-700/40 text-sm mb-6">我们是您的专属 AI 导游团队</p>

            {/* Navigation Grid - Original Light Style */}
            <div className="grid grid-cols-2 gap-3 mb-2">
                {/* 1. Tour - Agent A (Blue) */}
                <button 
                    onClick={() => handleNavigation('tour')}
                    className="col-span-1 bg-white/40 hover:bg-white/60 border border-teal-100/30 hover:border-teal-100/50 rounded-2xl p-4 text-left flex flex-col justify-between h-20 btn-press relative overflow-hidden group"
                >
                    <Icon name="map" className="w-5 h-5 text-teal-600/50 mb-2" />
                    <div>
                        <h3 className="font-medium text-teal-900/50 text-sm leading-tight">小A伴你游</h3>
                        <p className="text-[10px] text-teal-700/30 mt-1">智能路线规划</p>
                    </div>
                </button>

                {/* 2. Culture - Agent B/Red (Green) */}
                <button 
                    onClick={() => handleNavigation('culture')}
                    className="col-span-1 bg-white/40 hover:bg-white/60 border border-teal-100/30 hover:border-teal-100/50 rounded-2xl p-4 text-left flex flex-col justify-between h-20 btn-press relative overflow-hidden group"
                >
                    <Icon name="academic-cap" className="w-5 h-5 text-teal-600/50 mb-2" />
                    <div>
                        <h3 className="font-medium text-teal-900/50 text-sm leading-tight">人文典故</h3>
                        <p className="text-[10px] text-teal-700/30 mt-1">历史印记</p>
                    </div>
                </button>

                {/* 3. Specials/Fengwuzhi */}
                <button 
                    onClick={() => handleNavigation('specials')}
                    className="col-span-2 bg-white/40 hover:bg-white/60 border border-teal-100/30 hover:border-teal-100/50 rounded-2xl p-3 flex items-center justify-between h-14 btn-press relative overflow-hidden group"
                >
                    <div className="flex items-center space-x-3">
                         <div className="w-8 h-8 bg-purple-50/50 rounded-lg flex items-center justify-center">
                             <Icon name="camera" className="w-4 h-4 text-purple-500/50" />
                         </div>
                         <div>
                            <h3 className="font-medium text-teal-900/50 text-sm">风物志</h3>
                            <p className="text-xs text-teal-700/30">地道风物 & 自然生态</p>
                         </div>
                    </div>
                    <Icon name="arrow-left" className="w-4 h-4 text-teal-400/30 transform rotate-180" />
                </button>

                {/* 4. Market/Shopping */}
                <button 
                    onClick={() => handleNavigation('market')}
                    className="col-span-2 bg-white/40 hover:bg-white/60 border border-teal-100/30 hover:border-teal-100/50 rounded-2xl p-3 flex items-center justify-between h-14 btn-press relative overflow-hidden group"
                >
                    <div className="flex items-center space-x-3">
                         <div className="w-8 h-8 bg-pink-50/50 rounded-lg flex items-center justify-center">
                             <Icon name="bag" className="w-4 h-4 text-pink-500/50" />
                         </div>
                         <div>
                            <h3 className="font-medium text-teal-900/50 text-sm">家乡集</h3>
                            <p className="text-xs text-teal-700/30">特产好物 & 助农扶贫</p>
                         </div>
                    </div>
                     <Icon name="arrow-left" className="w-4 h-4 text-teal-400/30 transform rotate-180" />
                </button>
            </div>
            
        </div>
      </div>
    </div>
  );
};

export default WelcomeModal;
