
import React from 'react';
import { Celebrity } from '../types';

const mockCelebrities: Celebrity[] = [
  {
    id: 'c_song',
    name: '宋渊源',
    title: '辛亥革命猛将',
    description: '追随孙中山，投身民主革命',
    imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E5%AE%8B%E6%B8%8A%E6%BA%90.jpg?e=1763669775&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:4TorkmcfnwZqC0G3v8ZAdG4MCuI=',
    detailText: '宋渊源（1881—1961），字子清，福建永春人。早年加入中国同盟会，追随孙中山先生投身辛亥革命。他性格豪爽，作战勇猛，在光复福建的战役中立下赫赫战功。民国成立后，致力于家乡建设与教育事业，是永春著名的革命先驱。'
  },
  {
    id: 'c_zheng',
    name: '郑玉指',
    title: '辛亥革命先驱',
    description: '获孙中山亲颁“旌义状”',
    imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E9%83%91%E7%8E%89%E6%8C%87.jpg?e=1763669706&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:nAe770mU7HZ29Qiz1BOj7Uaw1Mg=',
    detailText: '郑玉指（1851—1929年），字绳摇，永春仙夹东里村人。早年出洋到马来亚的槟榔屿谋生，后经商发达。1906年加入中国同盟会，成为槟榔屿分会第一批会员。他毁家纾难，多次慷慨捐输巨资支持孙中山的革命活动。1912年，孙中山亲颁“旌义状”，表彰其“宣扬大义，不遗余力”。'
  },
  {
    id: 'c_li',
    name: '李铁民',
    title: '永春华侨革命党第一笔',
    description: '以笔为枪，宣传革命思想',
    imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E6%9D%8E%E9%93%81%E6%B0%91.jpg?e=1763669601&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:vshvF183VpJxjmV69Qy3ac2wngs=',
    detailText: '李铁民（1898—1956），原名李赋京，福建永春人。归侨，著名侨领。早年在南洋加入同盟会，创办报刊，撰写大量文章宣传反清革命思想，被誉为“永春华侨革命党第一笔”。一生致力于维护华侨权益，支持祖国革命与建设。'
  },
  {
    id: 'c_cheng',
    name: '郑成快',
    title: '辛亥革命二等奖章获得者',
    description: '英勇无畏，功勋卓著',
    imageUrl: 'http://t61i76pjk.hn-bkt.clouddn.com/dongli/pic/%E9%83%91%E6%88%90%E5%BF%AB.jpg-50?e=1763669651&token=KPjDX5JKdPj4uqjNpBSO-Eln4XWXDvgjed5-J4kE:_4fjPmV1QiyEVlScPDO5VjN0yBg=',
    detailText: '郑成快，福建永春东里人。辛亥革命时期积极响应号召，投身革命队伍。在光复福州等战役中表现英勇，冲锋在前，不畏牺牲。因其在推翻清朝统治、建立民国过程中的杰出贡献，荣获辛亥革命二等奖章，是东里村的骄傲。'
  }
];

const CelebrityCard: React.FC<{ celebrity: Celebrity }> = ({ celebrity }) => {
  // 映射主应用的人物ID到mingrenguan页面的人物ID
  const idMap: { [key: string]: string } = {
    'c_li': 'li-tiemin',
    'c_song': 'song-yuan', 
    'c_cheng': 'zheng-chengkuai',
    'c_zheng': 'zheng-yuzhi'
  };

  const handleClick = () => {
    const mappedId = idMap[celebrity.id] || celebrity.id;
    // mingrenguan项目运行在端口3001，需要跳转到正确的URL
    // 在生产环境中，可能需要根据实际部署情况调整这个URL
    const baseUrl = window.location.port === '3000' 
      ? `${window.location.protocol}//${window.location.hostname}:3001`
      : `${window.location.origin}/mingrenguan`;
    window.location.href = `${baseUrl}/#figure=${mappedId}`;
  };

  return (
    <div 
      onClick={handleClick}
      className="relative flex-shrink-0 w-40 h-56 rounded-xl overflow-hidden shadow-premium cursor-pointer group transition-transform duration-300 hover:scale-105 card-hover btn-press"
    >
      <img 
        src={celebrity.imageUrl} 
        alt={celebrity.name} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[30%] group-hover:grayscale-0" 
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/90"></div>
      <div className="absolute bottom-0 left-0 right-0 p-4 text-white/90 text-center">
        <p className="text-[10px] bg-teal-600/40 px-1.5 py-0.5 rounded inline-block mb-2 backdrop-blur-sm">{celebrity.title}</p>
        <h4 className="font-serif-brand font-bold text-lg leading-tight mb-1 text-white/95">{celebrity.name}</h4>
        <p className="text-[10px] opacity-60 line-clamp-2 text-white/80">{celebrity.description}</p>
      </div>
    </div>
  );
};

const CelebritySection: React.FC = () => {
  return (
    <div className="mt-8 mb-4 px-2 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
      <div className="flex items-baseline justify-between mb-4 px-2">
        <div>
           <h2 className="text-2xl font-serif-brand font-bold text-gray-800">名人堂</h2>
           <p className="text-xs text-gray-500 mt-1 tracking-widest font-light">往昔峥嵘 风骨长隽</p>
        </div>
        <span className="text-xs text-teal-600 font-medium">点击进入专题页面 &rarr;</span>
      </div>

      <div className="flex space-x-4 overflow-x-auto pb-6 px-2 scrollbar-hide snap-x">
        {mockCelebrities.map(celebrity => (
          <CelebrityCard 
            key={celebrity.id} 
            celebrity={celebrity} 
          />
        ))}
         <div className="flex-shrink-0 w-20 h-56 rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center text-gray-400 snap-center">
            <span className="text-xs">更多先辈</span>
            <span className="text-xs">敬请期待</span>
         </div>
      </div>
    </div>
  );
};

export default CelebritySection;
