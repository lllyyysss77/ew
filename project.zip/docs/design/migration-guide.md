# 样式统一改造指南（Migration Guide）

目标：在不改变交互与业务逻辑的前提下，统一视觉与样式，对齐 shadcn-ui 的设计体系，强调人文绿色旅行的 L 级质感。

## 步骤总览
1. 注入 Design Tokens
   - 新增 `src/lib/design/tokens.ts`（TS 常量）
   - 新增 `src/styles/theme.css`（CSS 变量与工具类：glass-card、glass-panel、gradient-primary、soft-glow）
2. 集成 Tailwind 与主题扩展
   - 新增 `tailwind.config.ts`，`darkMode: "class"`
   - 新增 `postcss.config.js`
   - 在 `index.css` 顶部引入 `@import "./src/styles/theme.css";` 并加入 `@tailwind base; @tailwind components; @tailwind utilities;`
3. 全局风格校准
   - 全局字体、背景与基础颜色对齐中性色
   - 提供按钮（`.btn`、`.btn-outline`）、卡片（`.card`）、输入框（`.input`）、标签（`.label`）等统一类
4. 组件微调（保持逻辑不动）
   - 将组件容器替换为 `glass-card` / `glass-panel`
   - 按钮与交互统一使用 `.btn` / `.btn-outline`，或直接使用 `bg-primary text-primary-foreground`
   - 文字颜色、边框与间距使用 Tailwind 的扩展主题（`neutral-*`、`rounded-*`、`shadow-*`）
5. 暗色模式
   - 保持 class 策略：在 `html` 上切换 `dark` 类
   - `theme.css` 已提供暗色映射，无需额外逻辑
6. 代码质量
   - 继续沿用现有结构，不重构业务
   - 类名遵循语义与尺寸前缀（例如：`btn`, `card`, `input`, `label`），与 Tailwind 通用类结合

## 变更范围
- 新增文件：`src/lib/design/tokens.ts`, `src/styles/theme.css`, `tailwind.config.ts`, `postcss.config.js`, `docs/design/*`, `src/pages/style-preview.tsx`
- 校准文件：`index.css`, `index.html`（暗色初始化）

## 验证方法
- 构建：`pnpm i && pnpm run build`
- 预览：`pnpm run preview`
- 暗色：开发者工具添加/移除 `html.dark` 即可验证暗色映射
- 风格对比：访问 `src/pages/style-preview.tsx` 组件以预览 tokens 与统一组件效果（如需挂载到路由或入口，可在不改变现有交互的前提下进行增量集成）