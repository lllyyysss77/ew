# 前端视觉现状审计（Style Audit）

本审计基于以下文件的快速巡检：
- index.css
- styles/design-system.css
- App.tsx / index.tsx
- components/WelcomeModal.tsx
- components/FloatingAgentBar.tsx
- components/common/Icon.tsx

## 发现的问题（不一致点）
1. 颜色使用不统一
   - index.css 与 design-system.css 中存在多处直接使用硬编码颜色（例如 `#fff`, `#000`, `rgba(...)`），缺乏主色/中性色的统一定义。
   - 组件中未统一使用主题色，按钮、背景、边框色各自独立选择，导致整体观感不连贯。

2. 阴影与圆角风格不一致
   - 部分组件使用尖锐圆角或无圆角，另一些组件使用大圆角；阴影强弱不一且样式多样（有的没有阴影，有的使用 `box-shadow: 0 0 10px ...`）
   - 不符合 L 级质感（柔和、层次分明）的统一风格。

3. 间距与排版未统一
   - 组件之间与内部的 padding/margin 数值各异，缺少设计 token 的间距刻度。
   - 字体大小与行高未统一，存在不同字号的随意使用。

4. 渐变与光晕运用不稳定
   - 有少量背景图和渐变，但未形成系统；“弥散光（柔和光晕）”效果没有统一的实现方式。

5. 毛玻璃（磨砂玻璃）缺少统一实现
   - 少量使用 `backdrop-filter: blur()`，但没有标准化的透明度、边框、阴影搭配，整体观感偏杂。

6. 深色模式缺失
   - 项目未接入统一暗色模式（class 策略），没有成体系的暗色 token 映射。

7. 类名与工具库
   - Tailwind 与 shadcn-ui 未集成；样式主要靠自定义 CSS，与组件库风格没有一致对齐。
   - 类名约定缺少统一规范（例如状态、尺寸、语义类的前缀与命名）。

## 统一方向（对齐 shadcn-ui）
- 使用 Design Tokens 管理颜色、圆角、阴影、间距、渐变与毛玻璃参数，导出到 CSS 变量与 TypeScript 常量。
- 通过 Tailwind CSS 的 `extend` 配置对齐 shadcn-ui 的主题体系（颜色、阴影、圆角）。
- 使用暗色模式（`dark` class）策略，提供成套的暗色映射。
- 尽量复用现有结构与逻辑，仅替换样式为 tokens 与统一工具类。

## 目标视觉关键词
- 人文、绿色旅行、弥散光（柔和光晕/模糊）
- 自然系渐变（以自然绿为主）、磨砂玻璃（适度透明与景深）

## 后续执行计划（对应任务）
1. 设计 Design Tokens（CSS 变量与 TS 常量）
2. 集成 Tailwind + 对齐 shadcn-ui 主题（`tailwind.config.ts`）
3. 全局样式（`src/styles/theme.css`）与必要校准（`index.css`）
4. 逐步将组件样式替换为 tokens，保持逻辑不动
5. 暗色模式接入（class 策略）
6. ESLint/Prettier 与类名约定
7. 输出统一规范/示例与迁移指南