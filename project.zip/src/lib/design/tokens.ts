/**
 * Design Tokens - 对齐 shadcn-ui 风格，强调人文绿色旅行、弥散光、渐变、磨砂玻璃
 * 仅用于样式常量引用，不改变业务逻辑
 */
export const colors = {
  // 自然绿为主
  primary: {
    DEFAULT: "hsl(142 72% 35%)", // 绿色主色（自然系）
    foreground: "hsl(0 0% 100%)",
    hover: "hsl(142 72% 30%)",
    ring: "hsl(142 60% 45%)",
  },
  secondary: {
    DEFAULT: "hsl(199 70% 43%)", // 湖水蓝，用于点缀
    foreground: "hsl(0 0% 100%)",
  },
  accent: {
    DEFAULT: "hsl(32 90% 55%)", // 暖阳点缀
    foreground: "hsl(0 0% 100%)",
  },
  // 中性色（对齐 shadcn-ui）
  neutral: {
    50: "hsl(0 0% 98%)",
    100: "hsl(0 0% 96%)",
    200: "hsl(0 0% 92%)",
    300: "hsl(0 0% 87%)",
    400: "hsl(0 0% 74%)",
    500: "hsl(0 0% 60%)",
    600: "hsl(0 0% 47%)",
    700: "hsl(0 0% 35%)",
    800: "hsl(0 0% 20%)",
    900: "hsl(0 0% 12%)",
  },
  success: "hsl(142 70% 45%)",
  warning: "hsl(38 92% 50%)",
  danger: "hsl(0 72% 55%)",
};

export const radius = {
  sm: "8px",
  md: "12px",
  lg: "16px",
  xl: "24px",
  full: "9999px",
};

export const shadow = {
  sm: "0 1px 2px rgba(16, 24, 40, 0.08)",
  md: "0 4px 12px rgba(16, 24, 40, 0.12)",
  lg: "0 8px 24px rgba(16, 24, 40, 0.16)",
  glow: "0 0 40px rgba(67, 160, 71, 0.25)", // 弥散光
};

export const spacing = {
  xs: "4px",
  sm: "8px",
  md: "12px",
  lg: "16px",
  xl: "24px",
  "2xl": "32px",
};

export const glass = {
  // 毛玻璃（磨砂）参数
  background: "rgba(255, 255, 255, 0.08)",
  border: "rgba(255, 255, 255, 0.25)",
  blur: "12px",
  shadow: shadow.md,
};

export const gradient = {
  primary: "linear-gradient(135deg, hsl(142 72% 35%), hsl(199 70% 43%))",
  softGlow:
    "radial-gradient(1200px circle at top left, rgba(67,160,71,0.25), transparent 40%), radial-gradient(800px circle at bottom right, rgba(25,118,210,0.20), transparent 40%)",
};

export const typography = {
  fontFamily: "Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, 'Apple Color Emoji', 'Segoe UI Emoji'",
  lineHeight: {
    normal: 1.5,
    snug: 1.35,
  },
  size: {
    xs: "12px",
    sm: "14px",
    md: "16px",
    lg: "18px",
    xl: "20px",
    "2xl": "24px",
  },
};