import React from "react";

export default function StylePreview() {
  return (
    <div className="min-h-screen page-soft-glow p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <header className="glass-panel p-6">
          <h1 className="text-2xl font-semibold text-neutral-900 dark:text-neutral-100">
            视觉风格预览（shadcn 对齐）
          </h1>
          <p className="text-neutral-700 dark:text-neutral-300 mt-2">
            自然绿、人文旅行、弥散光、渐变与毛玻璃示例。
          </p>
        </header>

        {/* Colors */}
        <section className="glass-card p-6">
          <h2 className="text-xl font-semibold mb-4">颜色（Color Palette）</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="h-16 rounded-md shadow-md bg-primary" />
            <div className="h-16 rounded-md shadow-md bg-secondary" />
            <div className="h-16 rounded-md shadow-md bg-accent" />
            <div className="h-16 rounded-md shadow-md bg-neutral-200" />
          </div>
        </section>

        {/* Gradients & Glass */}
        <section className="glass-card p-6 space-y-4">
          <h2 className="text-xl font-semibold">渐变与弥散光</h2>
          <div className="h-24 rounded-xl shadow-glow gradient-primary" />
          <div className="h-24 rounded-xl shadow-lg soft-glow" />
        </section>

        {/* Components */}
        <section className="glass-card p-6 space-y-4">
          <h2 className="text-xl font-semibold">常用组件示例（对齐 shadcn）</h2>
          <div className="flex flex-wrap items-center gap-3">
            <button className="btn">主按钮</button>
            <button className="btn-outline">次按钮</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="card">
              <div className="space-y-2">
                <label className="label">输入框</label>
                <input className="input" placeholder="请输入..." />
                <p className="text-xs text-neutral-600">说明文本</p>
              </div>
            </div>
            <div className="card">
              <p className="text-neutral-800 dark:text-neutral-200">
                卡片内容示例。毛玻璃与柔和阴影确保 L 级质感。
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}