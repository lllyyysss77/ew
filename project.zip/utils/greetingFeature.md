# Agent 打招呼功能说明

## 功能概述

当用户首次打开网页或每天第一次访问时，Agent会主动打招呼，提供个性化的欢迎体验。

## 实现细节

### 1. 打招呼逻辑

- **触发时机**: 用户打开页面2秒后
- **触发条件**: 当天首次访问（使用localStorage记录）
- **显示内容**: "您来啦～小A等您很久啦！我是今天的小小村官儿～ 我来为您服务🌟"
- **语音播放**: 可选的语音问候（使用浏览器TTS）

### 2. 存储机制

```javascript
// 使用localStorage记录每日访问
localStorage.setItem('agent_greeted_today', new Date().toDateString());
```

### 3. 实现位置

#### FloatingAgentBar.tsx
- 在组件挂载时检查是否需要打招呼
- 延迟2秒后自动打开聊天窗口并显示欢迎消息
- 支持语音播放

#### AgentPresenter.tsx  
- 集成到初始消息逻辑中
- 根据是否首次访问显示不同的欢迎内容
- 跟踪打招呼事件

### 4. 事件跟踪

打招呼行为会被页面感知系统记录：

```javascript
pageAwareness.trackCustomEvent('interaction', {
  action: 'greeting',
  source: 'auto',
  timestamp: Date.now()
});
```

## 用户体验

### 首次访问（当天）
1. 用户打开网页
2. 浏览页面2秒
3. Agent聊天窗口自动打开
4. 显示欢迎消息："您来啦～小A等您很久啦！"
5. （可选）播放语音问候

### 非首次访问（当天）
- 显示正常的初始欢迎消息
- 不会重复打招呼

### 第二天访问
- 重置状态，再次显示打招呼
- 提供每日新鲜感

## 自定义配置

### 修改延迟时间
```javascript
// 在 FloatingAgentBar.tsx 中修改
}, 2000); // 改为其他毫秒数
```

### 修改欢迎消息
```javascript
text: '您来啦～小A等您很久啦！我是今天的小小村官儿～ 我来为您服务🌟'
```

### 修改语音设置
```javascript
const utterance = new SpeechSynthesisUtterance('您来啦，小A等您很久啦...');
utterance.lang = 'zh-CN';
utterance.rate = 0.9;    // 语速
utterance.pitch = 1.1;    // 音调
```

## 测试方法

1. **清除localStorage**:
   ```javascript
   localStorage.removeItem('agent_greeted_today');
   ```

2. **刷新页面**，应该看到打招呼消息

3. **再次刷新**，应该看到正常的初始消息

4. **修改系统日期**到第二天，再次刷新应该重新打招呼

## 注意事项

- 打招呼功能每天只触发一次
- 使用localStorage存储，清除浏览器数据会重置状态
- 语音功能依赖浏览器支持，不支持时会静默失败
- 可以通过修改localStorage键名来重置每日状态

## 扩展可能

1. **个性化问候**: 根据时间段显示不同问候语
2. **天气相关**: 结合天气信息调整问候内容  
3. **节日特殊**: 特定节日显示特殊问候
4. **用户记忆**: 记住用户偏好，提供个性化欢迎