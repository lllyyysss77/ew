# 页面感知系统使用指南

## 概述

页面感知系统 (`pageAwareness.ts`) 提供了以下功能：
- 监听用户点击、滚动等行为
- 提取页面关键词和上下文信息
- 为Agent提供智能感知能力
- 生成个性化的建议和主动消息

## 如何在组件中添加数据属性

### 1. 景点相关元素

```tsx
// 景点卡片
<div 
  className="spot-card"
  data-spot="永春辛亥革命纪念馆"
  data-keyword="历史"
  data-category="attraction"
>
  <h3>永春辛亥革命纪念馆</h3>
  <p>了解辛亥革命历史</p>
</div>

// 标签按钮
<button
  className="tag-button"
  data-spot={spot.name}
  data-keyword="拍照"
  data-category="tag"
>
  📸 拍照打卡
</button>
```

### 2. 功能按钮

```tsx
// 知识查询按钮
<button
  onClick={handleKnowledge}
  data-spot={spot.name}
  data-keyword="历史"
  data-category="knowledge"
>
  📚 了解历史
</button>

// 拍照功能
<button
  onClick={handlePhoto}
  data-spot={spot.name}
  data-keyword="拍照"
  data-category="photo"
>
  📷 生成明信片
</button>
```

### 3. 页面区域

```tsx
// 名人堂区域
<div id="section-celebrity" data-section="celebrity">
  <HallOfFame />
</div>

// 特产区域
<div id="section-specials" data-section="specials">
  <LocalSpecialsSection />
</div>
```

## Agent如何使用页面感知

### 1. 在Agent组件中集成

```tsx
import { useAgentAwareness } from '../hooks/useAgentAwareness';

const MyAgent = () => {
  const { 
    context, 
    getContextualSuggestions, 
    getProactiveMessage,
    trackAgentAction 
  } = useAgentAwareness();

  // 获取智能建议
  const suggestions = getContextualSuggestions(baseSuggestions);

  // 获取主动消息
  const proactiveMsg = getProactiveMessage();

  // 跟踪用户行为
  const handleUserQuery = (text: string) => {
    trackAgentAction('user_query', { text, spot: context.currentSpot });
    // ... 处理查询逻辑
  };

  return (
    <div>
      {/* 显示当前上下文 */}
      {context.currentSpot && (
        <div>当前关注: {context.currentSpot}</div>
      )}
      
      {/* 主动消息 */}
      {proactiveMsg && <div>{proactiveMsg}</div>}
      
      {/* 智能建议 */}
      {suggestions.map(s => <button key={s}>{s}</button>)}
    </div>
  );
};
```

### 2. 支持的数据属性

| 属性 | 用途 | 示例 |
|------|------|------|
| `data-spot` | 标识景点名称 | `data-spot="永春辛亥革命纪念馆"` |
| `data-keyword` | 提取关键词 | `data-keyword="历史"` |
| `data-category` | 分类信息 | `data-category="attraction"` |
| `data-section` | 页面区域 | `data-section="celebrity"` |

### 3. 自动识别的关键词

系统会自动识别以下类型的关键词：
- **景点相关**: 纪念馆、古桥、瀑布、水库、古寨、廊桥、祠堂、民居
- **活动相关**: 拍照、游览、参观、打卡、购物、美食、特产
- **特色相关**: 历史、文化、自然、生态、传统、建筑、风景

## 最佳实践

1. **为重要元素添加数据属性**: 特别是用户可能点击的按钮和链接
2. **使用有意义的关键词**: 选择能代表用户意图的词汇
3. **合理分类**: 使用 `data-category` 对元素进行分类
4. **区域标记**: 为主要页面区域添加 `data-section` 标识
5. **性能考虑**: 避免在频繁变化的元素上添加过多数据属性

## 示例效果

- 用户点击"拍照"标签 → Agent知道用户对拍照感兴趣
- 用户在名人堂区域停留 → Agent主动介绍名人故事
- 用户多次点击历史相关内容 → Agent推荐更多历史景点
- 用户在特产区浏览 → Agent询问是否需要购买推荐

这样，Agent就能真正"感知"用户的行为和兴趣，提供更智能的服务！