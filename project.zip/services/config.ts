
// Configuration constants
// Extracted for clarity and easier environment management

export const AI_CONFIG = {
  WEBHOOK_URL: (import.meta as any).env?.VITE_WEBHOOK_URL || '',
  
  SILICON_FLOW: {
    BASE_URL: 'https://api.siliconflow.cn/v1',
    API_KEY: (import.meta as any).env?.VITE_SILICON_FLOW_API_KEY || '',
    MODELS: {
      TEXT: 'deepseek-ai/DeepSeek-R1-Distill-Qwen-7B', 
      REASONING: 'deepseek-ai/DeepSeek-R1-Distill-Qwen-7B',
      IMAGE: 'Kwai-Kolors/Kolors',
    }
  },
  ZHIPU: {
    BASE_URL: 'https://open.bigmodel.cn/api/paas/v4',
    API_KEY: (import.meta as any).env?.VITE_ZHIPU_API_KEY || '',
    MODELS: {
      TEXT: 'GLM-4-Flash',
      VISION: 'GLM-4V-Flash'
    }
  },
  MINIMAX: {
    BASE_URL: 'https://api.minimax.chat/v1',
    API_KEY: (import.meta as any).env?.VITE_MINIMAX_API_KEY || '',
    GROUP_ID: (import.meta as any).env?.VITE_MINIMAX_GROUP_ID || '', 
    MODELS: {
      TEXT: 'abab6.5s-chat',
      AUDIO: 'speech-01-turbo'
    }
  }
};

export const AMAP_CONFIG = {
  MCP_URL: 'https://mcp.api-inference.modelscope.net/d19a443b23994d/mcp'
};
