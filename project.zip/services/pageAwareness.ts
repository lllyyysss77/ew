/**
 * 页面事件监听和Agent感知系统
 * 用于监听用户行为、页面关键词，并提供给Agent使用
 */

export interface PageEvent {
  id: string;
  timestamp: number;
  type: 'click' | 'scroll' | 'hover' | 'search' | 'navigation' | 'tag_click' | 'spot_view' | 'interaction';
  element?: {
    tagName: string;
    id?: string;
    className?: string;
    text?: string;
    dataset?: Record<string, string>;
  };
  data?: {
    spotName?: string;
    keyword?: string;
    category?: string;
    section?: string;
    value?: any;
  };
  context?: {
    url: string;
    title: string;
    scrollY: number;
    viewport: { width: number; height: number };
  };
}

export interface AgentInsight {
  currentSpot: string | null;
  userInterests: string[];
  recentKeywords: string[];
  activeSection: string | null;
  interactionCount: number;
  lastActivity: number;
  sessionDuration: number;
}

class PageAwarenessSystem {
  private events: PageEvent[] = [];
  private insights: AgentInsight = {
    currentSpot: null,
    userInterests: [],
    recentKeywords: [],
    activeSection: null,
    interactionCount: 0,
    lastActivity: Date.now(),
    sessionDuration: 0
  };
  private listeners: Set<(insights: AgentInsight) => void> = new Set();
  private sessionStartTime = Date.now();
  private sectionObserver: IntersectionObserver | null = null;
  private clickHandler: ((e: MouseEvent) => void) | null = null;

  constructor() {
    this.initialize();
  }

  private initialize() {
    // 设置点击监听
    this.clickHandler = this.handleClick.bind(this);
    document.addEventListener('click', this.clickHandler, true);

    // 设置滚动监听
    window.addEventListener('scroll', this.handleScroll.bind(this), { passive: true });

    // 设置页面区域监听
    this.setupSectionObserver();

    // 定期更新会话时长
    setInterval(() => {
      this.insights.sessionDuration = Date.now() - this.sessionStartTime;
      this.notifyListeners();
    }, 5000);
  }

  private handleClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!target) return;

    const pageEvent: PageEvent = {
      id: this.generateEventId(),
      timestamp: Date.now(),
      type: 'click',
      element: this.extractElementInfo(target),
      context: this.getPageContext()
    };

    // 提取关键词和数据
    this.extractKeywordsFromElement(target, pageEvent);
    
    this.addEvent(pageEvent);
    this.updateInsights(pageEvent);
  }

  private handleScroll() {
    // 检测当前活跃的区域
    const sections = document.querySelectorAll('[id^="section-"], [data-section]');
    let activeSection: string | null = null;

    sections.forEach(section => {
      const rect = section.getBoundingClientRect();
      if (rect.top <= window.innerHeight * 0.6 && rect.bottom >= window.innerHeight * 0.4) {
        activeSection = section.id || (section as HTMLElement).dataset.section || null;
      }
    });

    if (activeSection && activeSection !== this.insights.activeSection) {
      this.insights.activeSection = activeSection;
      this.notifyListeners();
    }
  }

  private setupSectionObserver() {
    if ('IntersectionObserver' in window) {
      this.sectionObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              const sectionId = entry.target.id;
              if (sectionId.startsWith('section-')) {
                this.insights.activeSection = sectionId;
                this.notifyListeners();
              }
            }
          });
        },
        { threshold: 0.5 }
      );

      // 观察所有section
      document.querySelectorAll('[id^="section-"]').forEach(section => {
        this.sectionObserver?.observe(section);
      });
    }
  }

  private extractElementInfo(element: HTMLElement): PageEvent['element'] {
    return {
      tagName: element.tagName.toLowerCase(),
      id: element.id,
      className: element.className,
      text: element.textContent?.slice(0, 100) || '',
      dataset: { ...element.dataset }
    };
  }

  private extractKeywordsFromElement(element: HTMLElement, event: PageEvent) {
    // 从data属性中提取关键词
    if (element.dataset.spot) {
      event.data = { ...event.data, spotName: element.dataset.spot };
      this.insights.currentSpot = element.dataset.spot;
    }

    if (element.dataset.keyword) {
      event.data = { ...event.data, keyword: element.dataset.keyword };
      this.addKeyword(element.dataset.keyword);
    }

    if (element.dataset.category) {
      event.data = { ...event.data, category: element.dataset.category };
    }

    // 从文本中提取关键词
    const text = element.textContent || '';
    const keywords = this.extractKeywordsFromText(text);
    keywords.forEach(keyword => this.addKeyword(keyword));

    // 检测特殊交互类型
    if (element.classList.contains('tag-button') || element.closest('.tag-button')) {
      event.type = 'tag_click';
    }

    if (element.closest('[data-spot]')) {
      event.type = 'spot_view';
    }
  }

  private extractKeywordsFromText(text: string): string[] {
    // 简单的关键词提取逻辑
    const keywords: string[] = [];
    
    // 景点相关关键词
    const spotKeywords = ['纪念馆', '古桥', '瀑布', '水库', '古寨', '廊桥', '祠堂', '民居'];
    const activityKeywords = ['拍照', '游览', '参观', '打卡', '购物', '美食', '特产'];
    const featureKeywords = ['历史', '文化', '自然', '生态', '传统', '建筑', '风景'];

    [...spotKeywords, ...activityKeywords, ...featureKeywords].forEach(keyword => {
      if (text.includes(keyword)) {
        keywords.push(keyword);
      }
    });

    return keywords;
  }

  private getPageContext(): PageEvent['context'] {
    return {
      url: window.location.href,
      title: document.title,
      scrollY: window.scrollY,
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      }
    };
  }

  private addKeyword(keyword: string) {
    if (!keyword || keyword.length < 2) return;
    
    // 添加到最近关键词
    this.insights.recentKeywords = [
      keyword,
      ...this.insights.recentKeywords.filter(k => k !== keyword).slice(0, 9)
    ];

    // 更新用户兴趣
    if (!this.insights.userInterests.includes(keyword)) {
      this.insights.userInterests.push(keyword);
      // 保持兴趣列表在合理大小
      if (this.insights.userInterests.length > 20) {
        this.insights.userInterests = this.insights.userInterests.slice(-15);
      }
    }
  }

  private addEvent(event: PageEvent) {
    this.events.push(event);
    // 保持事件列表在合理大小
    if (this.events.length > 100) {
      this.events = this.events.slice(-50);
    }
  }

  private updateInsights(event: PageEvent) {
    this.insights.interactionCount++;
    this.insights.lastActivity = Date.now();

    // 根据事件类型更新洞察
    if (event.data?.spotName) {
      this.insights.currentSpot = event.data.spotName;
    }

    this.notifyListeners();
  }

  private notifyListeners() {
    this.listeners.forEach(listener => {
      try {
        listener({ ...this.insights });
      } catch (error) {
        console.error('Error in page awareness listener:', error);
      }
    });
  }

  private generateEventId(): string {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // 公共API
  public subscribe(listener: (insights: AgentInsight) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  public getCurrentInsights(): AgentInsight {
    return { ...this.insights };
  }

  public getRecentEvents(limit: number = 10): PageEvent[] {
    return this.events.slice(-limit);
  }

  public trackCustomEvent(type: PageEvent['type'], data: any) {
    const event: PageEvent = {
      id: this.generateEventId(),
      timestamp: Date.now(),
      type,
      data,
      context: this.getPageContext()
    };
    
    this.addEvent(event);
    this.updateInsights(event);
  }

  public setCurrentSpot(spotName: string) {
    this.trackCustomEvent('spot_view', { spotName });
    this.insights.currentSpot = spotName;
    this.notifyListeners();
  }

  public destroy() {
    if (this.clickHandler) {
      document.removeEventListener('click', this.clickHandler);
    }
    if (this.sectionObserver) {
      this.sectionObserver.disconnect();
    }
    this.listeners.clear();
  }
}

// 创建全局实例
export const pageAwareness = new PageAwarenessSystem();

// 导出Hook用于React组件
export const usePageAwareness = () => {
  const [insights, setInsights] = React.useState(pageAwareness.getCurrentInsights());

  React.useEffect(() => {
    const unsubscribe = pageAwareness.subscribe(setInsights);
    return unsubscribe;
  }, []);

  return {
    insights,
    trackEvent: pageAwareness.trackCustomEvent.bind(pageAwareness),
    setCurrentSpot: pageAwareness.setCurrentSpot.bind(pageAwareness),
    getRecentEvents: pageAwareness.getRecentEvents.bind(pageAwareness)
  };
};