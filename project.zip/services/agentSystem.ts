import { AgentID, ANPMessage, SharedContext } from '../types';
import * as geminiService from './geminiService';

type MessageHandler = (msg: ANPMessage) => Promise<void>;

class AgentNetwork {
  private listeners: Record<string, MessageHandler> = {};
  private sharedContext: SharedContext = {
    userSession: { history: [] },
    environment: {},
    systemStatus: { agentHealth: {}, pendingTasks: 0 }
  };

  register(agentId: AgentID, handler: MessageHandler) {
    this.listeners[agentId] = handler;
    this.sharedContext.systemStatus.agentHealth[agentId] = 'online';
  }

  async dispatch(msg: ANPMessage) {
    // In production, log only essential traffic
    // console.log(`[ANP] ${msg.source} -> ${msg.target}`, msg.type);
    this.monitor(msg);

    if (msg.target === 'BROADCAST') {
      Object.values(this.listeners).forEach(h => h(msg));
    } else if (this.listeners[msg.target]) {
      await this.listeners[msg.target](msg);
    }
  }

  private monitor(msg: ANPMessage) {
    if (msg.type === 'EVENT' && msg.action === 'context_update') {
       this.sharedContext = { ...this.sharedContext, ...msg.payload };
    }
    if (msg.source === 'USER' && msg.action === 'query') {
        this.sharedContext.userSession.history.push(msg.payload.text);
    }
  }

  getContext() {
      return this.sharedContext;
  }
}

export const Network = new AgentNetwork();

// --- Agent B: Tool Runner ---

const tools = {
  'voice_interaction': geminiService.voiceInteraction,
  'object_recognition': geminiService.objectRecognition,
  'get_shopping_info': geminiService.getShoppingInfo,
  'get_related_knowledge': geminiService.getRelatedKnowledge,
  'get_map': geminiService.getStaticMapImage // Corrected mapping
};

Network.register('B', async (msg: ANPMessage) => {
  if (msg.type === 'REQUEST' && msg.action === 'call_tool') {
    const { toolName, params } = msg.payload;
    try {
      const tool = tools[toolName as keyof typeof tools];
      if (!tool) throw new Error(`Tool ${toolName} not found`);

      // @ts-ignore
      const result = await tool(...params);

      Network.dispatch({
        id: `resp_${Date.now()}`,
        timestamp: Date.now(),
        source: 'B',
        target: msg.source,
        type: 'RESPONSE',
        action: 'tool_result',
        payload: result
      });

      if (params[0] && typeof params[0] === 'string') {
          Network.dispatch({
              id: `evt_${Date.now()}`,
              timestamp: Date.now(),
              source: 'B',
              target: 'D',
              type: 'EVENT',
              action: 'context_update',
              payload: { userSession: { currentSpot: params[0] } }
          });
      }
    } catch (error: any) {
      Network.dispatch({
        id: `err_${Date.now()}`,
        timestamp: Date.now(),
        source: 'B',
        target: msg.source,
        type: 'ERROR',
        action: 'tool_failed',
        payload: { message: error.message }
      });
    }
  }
});

// --- Agent A: Facade ---

function parseIntent(text: string): { tool: string, isCommerce: boolean } {
    if (text.includes('买') || text.includes('吃')) return { tool: 'get_shopping_info', isCommerce: true };
    if (text.includes('历史') || text.includes('知识')) return { tool: 'get_related_knowledge', isCommerce: false };
    return { tool: 'voice_interaction', isCommerce: false };
}

export const AgentA = {
  processUserRequest: async (text: string, contextSpot: string, mode: 'text' | 'photo' = 'text'): Promise<any> => {
    return new Promise((resolve) => {
      const requestId = `req_${Date.now()}`;

      const responseHandler = async (msg: ANPMessage) => {
        if (msg.type === 'RESPONSE' || msg.type === 'ERROR') {
             if (msg.type === 'ERROR') {
                 resolve({ text: "服务暂时不可用。" });
             } else {
                 resolve(msg.payload);
             }
        }
      };
      
      Network.register('A', responseHandler);

      let toolName = 'voice_interaction';
      let params = [contextSpot, text];

      if (mode === 'photo') {
          toolName = 'object_recognition';
          params = [contextSpot];
      } else {
          const intent = parseIntent(text);
          if (intent.isCommerce) {
             toolName = 'get_shopping_info';
             params = ["118.205,25.235", contextSpot]; 
          } else if (intent.tool === 'get_related_knowledge') {
              toolName = 'get_related_knowledge';
              params = [contextSpot];
          }
      }

      Network.dispatch({
        id: requestId,
        timestamp: Date.now(),
        source: 'A',
        target: 'B',
        type: 'REQUEST',
        action: 'call_tool',
        payload: { toolName, params }
      });
    });
  }
};